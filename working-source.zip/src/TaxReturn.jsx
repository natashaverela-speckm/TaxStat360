import React from 'react'
import{useNavigate}from 'react-router-dom'
const e=React.createElement
const N='#0D1B3E',B='#2563EB',SL='#475569',G='#16a34a',R='#dc2626',GOLD='#FBBF24'
const fmt=n=>{const abs=Math.abs(Math.round(n)||0);return(n<0?'-':'')+'$'+abs.toLocaleString('en-US')}
const nv=v=>parseFloat((v||'').toString().replace(/[^0-9.-]/g,''))||0
const TAX_YR=new Date().getFullYear()
const BRACKETS={
  single:[[11600,.10],[47150,.12],[100525,.22],[191950,.24],[243725,.32],[609350,.35],[Infinity,.37]],
  mfj:   [[23200,.10],[94300,.12],[201050,.22],[383900,.24],[487450,.32],[731200,.35],[Infinity,.37]],
  mfs:   [[11600,.10],[47150,.12],[100525,.22],[191950,.24],[243725,.32],[365600,.35],[Infinity,.37]],
  hoh:   [[16550,.10],[63100,.12],[100500,.22],[191950,.24],[243700,.32],[609350,.35],[Infinity,.37]],
  qss:   [[23200,.10],[94300,.12],[201050,.22],[383900,.24],[487450,.32],[731200,.35],[Infinity,.37]]
}
const LTCG={
  single:[[47025,0],[518900,.15],[Infinity,.20]],
  mfj:   [[94050,0],[583750,.15],[Infinity,.20]],
  mfs:   [[47025,0],[291850,.15],[Infinity,.20]],
  hoh:   [[63000,0],[551350,.15],[Infinity,.20]],
  qss:   [[94050,0],[583750,.15],[Infinity,.20]]
}
const STD={single:14600,mfj:29200,mfs:14600,hoh:21900,qss:29200}
const NIIT_T={single:200000,mfj:250000,mfs:125000,hoh:200000,qss:250000}
const SALT_CAP=10000
const HSA_SINGLE=4150,HSA_FAMILY=8300
const SL_MAX=2500
function bTax(inc,st){const br=BRACKETS[st]||BRACKETS.single;let t=0,p=0;for(const[th,r]of br){if(inc<=p)break;t+=(Math.min(inc,th)-p)*r;p=th}return t}
function ltcgTax(ltcg,ordInc,st){
  if(ltcg<=0)return 0
  const br=LTCG[st]||LTCG.single;let tax=0,prev=0
  for(const[th,rate]of br){const top=Math.min(ordInc+ltcg,th),bot=Math.max(ordInc,prev);if(top>bot&&rate>0)tax+=(top-bot)*rate;prev=th;if(ordInc+ltcg<=th)break}
  return tax
}
function Tip({text}){
  const[show,setShow]=React.useState(false)
  return e('span',{style:{position:'relative',display:'inline-block',marginLeft:6}},
    e('span',{onClick:()=>setShow(s=>!s),style:{width:16,height:16,borderRadius:'50%',background:'#E2E8F0',color:SL,fontSize:10,fontWeight:700,display:'inline-flex',alignItems:'center',justifyContent:'center',cursor:'pointer',userSelect:'none'}},'i'),
    show&&e('div',{style:{position:'absolute',left:0,top:22,width:280,background:'#1E293B',color:'#F1F5F9',borderRadius:10,padding:'12px 14px',fontSize:12,lineHeight:1.6,zIndex:999,boxShadow:'0 8px 32px rgba(0,0,0,0.3)',border:'1px solid rgba(255,255,255,0.1)'}},
      e('div',{style:{marginBottom:8,fontWeight:700,color:'#FBBF24',fontSize:11}},'Where to find this'),
      text,
      e('div',{onClick:()=>setShow(false),style:{marginTop:10,fontSize:11,color:'#94A3B8',cursor:'pointer',textAlign:'right'}},'close')
    )
  )
}
function Section({title,icon,open:initOpen=false,children}){
  const[open,setOpen]=React.useState(initOpen)
  return e('div',{style:{background:'#fff',borderRadius:12,border:'1px solid #E2E8F0',marginBottom:12,overflow:'hidden'}},
    e('div',{onClick:()=>setOpen(o=>!o),style:{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'14px 18px',cursor:'pointer',background:open?'#F8FAFC':'#fff',borderBottom:open?'1px solid #E2E8F0':'none'}},
      e('div',{style:{display:'flex',alignItems:'center',gap:10}},
        e('span',{style:{fontSize:18}},(icon||'+')),
        e('span',{style:{fontSize:13,fontWeight:700,color:N}},title)
      ),
      e('span',{style:{fontSize:18,color:SL,transform:open?'rotate(180deg)':'none',transition:'transform 0.2s'}},'>>')
    ),
    open&&e('div',{style:{padding:'18px 18px 14px'}},children)
  )
}
const Fi=(label,val,set,tip,ph,hi)=>e('div',{style:{marginBottom:14}},
  e('div',{style:{display:'flex',alignItems:'center',marginBottom:5}},
    e('label',{style:{fontSize:12,fontWeight:700,color:SL}},label),
    tip&&e(Tip,{text:tip})
  ),
  e('input',{value:val,onChange:x=>set(x.target.value),placeholder:ph||'0',type:'number',
    style:{width:'100%',padding:'10px 14px',border:'1px solid '+(hi?'#86EFAC':'#E2E8F0'),borderRadius:8,fontSize:15,boxSizing:'border-box',fontFamily:'inherit',background:hi?'#F0FFF4':'#fff'}})
)
const Se=(label,val,set,opts,tip)=>e('div',{style:{marginBottom:14}},
  e('div',{style:{display:'flex',alignItems:'center',marginBottom:5}},
    e('label',{style:{fontSize:12,fontWeight:700,color:SL}},label),
    tip&&e(Tip,{text:tip})
  ),
  e('select',{value:val,onChange:x=>set(x.target.value),style:{width:'100%',padding:'10px 14px',border:'1px solid #E2E8F0',borderRadius:8,fontSize:14,background:'#fff',fontFamily:'inherit'}},
    ...opts.map(([v,l])=>e('option',{key:v,value:v},l)))
)
const Ck=(label,val,set,tip)=>e('div',{style:{display:'flex',alignItems:'flex-start',gap:10,marginBottom:12}},
  e('input',{type:'checkbox',checked:val,onChange:x=>set(x.target.checked),style:{width:16,height:16,marginTop:2,accentColor:B,cursor:'pointer'}}),
  e('div',null,
    e('span',{style:{fontSize:13,color:N,cursor:'pointer',fontWeight:600},onClick:()=>set(!val)},label),
    tip&&e(Tip,{text:tip})
  )
)
const Divider=()=>e('div',{style:{height:1,background:'#F1F5F9',margin:'12px 0'}})
const SubHead=t=>e('div',{style:{fontSize:11,fontWeight:700,color:SL,letterSpacing:'1px',marginBottom:10,marginTop:6}},t)
const Rw=(l,v,c,bold,indent)=>e('div',{style:{display:'flex',justifyContent:'space-between',padding:'5px 0',paddingLeft:indent?16:0,borderBottom:'1px solid rgba(255,255,255,0.07)'}},
  e('span',{style:{fontSize:indent?12:13,color:indent?'rgba(255,255,255,0.5)':'rgba(255,255,255,0.7)'}},l),
  e('span',{style:{fontSize:bold?14:12,fontWeight:bold?800:500,color:c||'#fff'}},v)
)
function calcTax(k1n,f){
  const fil=f.filing
  const isSE=['soleprop','smllc'].includes(f.entity)
  const isPass=['scorp','mmllc','partnership','soleprop','smllc'].includes(f.entity)
  const seBase=isSE?Math.max(0,k1n):0
  const seTax=seBase*0.9235*0.153,seDeduct=Math.round(seTax/2)
  const qbiCarryAmt=nv(f.qbiCarry)
  const qbi=isPass?Math.max(0,(k1n*0.20)-qbiCarryAmt):0
  const w2=nv(f.w2),interest=nv(f.interest),ordDiv=nv(f.ordDiv)
  const qualDiv=Math.min(nv(f.qualDiv),ordDiv)
  const stcg=nv(f.stcg),ltcg=nv(f.ltcg),rental=nv(f.rental)
  const nec=nv(f.nec),retirement=nv(f.retirement),otherInc=nv(f.otherInc)
  const ssBenefits=nv(f.ssBenefits)
  const comb=w2+k1n+interest+ordDiv+stcg+ltcg+rental+nec+(ssBenefits*0.5)
  const ssTax=(['single','mfs','hoh'].includes(fil))
    ?(comb<25000?0:comb<34000?Math.min(ssBenefits*.50,(comb-25000)*.50):Math.min(ssBenefits*.85,4500+(comb-34000)*.85))
    :(comb<32000?0:comb<44000?Math.min(ssBenefits*.50,(comb-32000)*.50):Math.min(ssBenefits*.85,6000+(comb-44000)*.85))
  const health=nv(f.health),hsa=Math.min(nv(f.hsa),f.hsaFamily?HSA_FAMILY:HSA_SINGLE)
  const sep=isSE?Math.min(nv(f.sep),Math.max(0,k1n)*0.25):nv(f.sep)
  const sl=Math.min(nv(f.sl),SL_MAX),alimonyPaid=nv(f.alimonyPaid)
  const alimonyRcvd=nv(f.alimonyRcvd)
  const grossIncome=k1n+w2+interest+ordDiv+stcg+ltcg+rental+nec+Math.round(ssTax)+retirement+alimonyRcvd+otherInc
  const agi=grossIncome-seDeduct-qbi-health-hsa-sep-sl-alimonyPaid
  let std=STD[fil]||STD.single
  const a65=f.age65?1:0,bli=f.blind?1:0
  if(fil==='single'||fil==='hoh')std+=(a65+bli)*1950;else std+=(a65+bli)*1550
  const mortgageInt=nv(f.mortgageInt),propTax=nv(f.propTax),stateIncomeTax=nv(f.stateIncomeTax)
  const salt=Math.min(propTax+stateIncomeTax,SALT_CAP)
  const charitable=Math.min(nv(f.charitable),agi*0.60)
  const medicalRaw=nv(f.medical),medicalDed=Math.max(0,medicalRaw-(agi*0.075))
  const itemized=mortgageInt+salt+charitable+medicalDed
  const useItemized=itemized>std,deduction=useItemized?itemized:std
  const deductionSavings=Math.abs(itemized-std)
  const nolCarryAmt=nv(f.nolCarry)
  const nolDeduction=Math.min(nolCarryAmt,Math.max(0,agi-deduction)*0.80)
  const ordinaryInc=Math.max(0,agi-deduction-nolDeduction-qualDiv-ltcg)
  const fedOrd=bTax(ordinaryInc,fil)
  const ltcgTotal=Math.max(0,qualDiv+ltcg),fedLTCG=ltcgTax(ltcgTotal,ordinaryInc,fil)
  const niitT=NIIT_T[fil]||NIIT_T.single
  const niit=agi>niitT?Math.max(0,Math.min(agi-niitT,ltcgTotal+rental))*.038:0
  const deps=Math.min(parseInt(f.deps)||0,6)
  const ctcPhaseout=fil==='mfj'?400000:200000
  const ctcRaw=deps*2000,ctcReduction=Math.ceil(Math.max(0,agi-ctcPhaseout)/1000)*50
  const ctc=Math.max(0,ctcRaw-ctcReduction)
  const careExp=nv(f.careExp),careMax=deps>=2?6000:3000
  const careRate=agi<=15000?.35:agi<=43000?.35-.01*Math.floor((agi-15000)/2000):.20
  const careCred=Math.min(careExp,careMax)*careRate
  const aocPhaseInc=fil==='mfj'?160000:80000
  let aoc=0
  if(agi<aocPhaseInc+20000){const ph=Math.max(0,Math.min(1,(aocPhaseInc+20000-agi)/20000));const ax=Math.min(nv(f.aocExp),4000);aoc=Math.round((ax>=2000?500+Math.min(ax-2000,2000)*.25:ax*.25+0)*ph)}
  const llcPhaseInc=fil==='mfj'?160000:80000
  let llc=0
  if(agi<llcPhaseInc+20000){const ph=Math.max(0,(llcPhaseInc+20000-agi)/20000);llc=Math.round(Math.min(2000,nv(f.llcExp)*.20*ph))}
  const saversMax=fil==='mfj'?77000:38500
  let savers=0
  if(agi<=saversMax){const sr=agi<=(fil==='mfj'?46380:23190)?.50:agi<=(fil==='mfj'?50590:25295)?.34:.10;savers=Math.round(Math.min(nv(f.retContrib)*sr,fil==='mfj'?4000:2000))}
  const totalCredits=ctc+careCred+aoc+llc+savers
  const grossTax=Math.max(0,Math.round(fedOrd+fedLTCG+seTax+niit-totalCredits))
  const w2Withheld=nv(f.w2Withheld),estPaid=nv(f.estPaid),totalPaid=w2Withheld+estPaid
  const netOwed=Math.max(0,grossTax-totalPaid),refund=totalPaid>grossTax?Math.round(totalPaid-grossTax):0
  return{grossIncome,agi,deduction,useItemized,itemized,std,deductionSavings,nolDeduction:Math.round(nolDeduction),qbiCarryAmt:Math.round(qbiCarryAmt),
    fedOrd:Math.round(fedOrd),fedLTCG:Math.round(fedLTCG),seTax:Math.round(seTax),
    seDeduct,qbi:Math.round(qbi),niit:Math.round(niit),
    ctc,careCred:Math.round(careCred),aoc,llc,savers,totalCredits,
    grossTax,totalPaid:Math.round(totalPaid),w2Withheld:Math.round(w2Withheld),estPaid:Math.round(estPaid),
    netOwed,refund,effRate:agi>0?((grossTax/agi)*100).toFixed(1):'0.0',
    salt:Math.round(salt),medicalDed:Math.round(medicalDed),charitable:Math.round(charitable),
    ssTax:Math.round(ssTax),qtr:Math.round(netOwed/4)}
}
export default function TaxReturn(){
  const nav=useNavigate()
  const k1s=sessionStorage.getItem('ts360_k1')||'0'
  const owns=sessionStorage.getItem('ts360_own')||'100'
  const[k1,setK1]=React.useState(k1s)
  const[res,setRes]=React.useState(null)
  const[uploading,setUploading]=React.useState(false)
  const[uploadMsg,setUploadMsg]=React.useState('')
  const[savedRecords,setSavedRecords]=React.useState(()=>{try{return JSON.parse(localStorage.getItem('ts360_records')||'[]')}catch{return[]}})
  const[recordName,setRecordName]=React.useState('')
  const[showSaveBox,setShowSaveBox]=React.useState(false)
  const[whatIfOpen,setWhatIfOpen]=React.useState(false)
  const[wif,setWif]=React.useState({})
  const[wifRes,setWifRes]=React.useState(null)
  const[f,setF]=React.useState({
    filing:'single',deps:'0',age65:false,blind:false,entity:'scorp',
    w2:'',w2Withheld:'',
    interest:'',ordDiv:'',qualDiv:'',stcg:'',ltcg:'',rental:'',nec:'',ssBenefits:'',retirement:'',alimonyRcvd:'',otherInc:'',
    health:'',hsa:'',hsaFamily:false,sep:'',sl:'',alimonyPaid:'',
    nolCarry:'',qbiCarry:'',
    mortgageInt:'',propTax:'',stateIncomeTax:'',charitable:'',medical:'',
    careExp:'',aocExp:'',llcExp:'',retContrib:'',estPaid:''
  })
  const sf=(k,v)=>setF(p=>({...p,[k]:v}))
  async function handlePaystubUpload(evt){
    const file=evt.target.files[0];if(!file)return
    setUploading(true);setUploadMsg('Reading paystub...')
    try{
      const toB64=f=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(',')[1]);r.onerror=rej;r.readAsDataURL(f)})
      const b64=await toB64(file)
      const resp=await fetch('https://05madmjrqd.execute-api.us-east-1.amazonaws.com/prod/paystub',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:[{role:'user',content:[{type:'document',source:{type:'base64',media_type:'application/pdf',data:b64}},{type:'text',text:'Extract from this paystub. Return JSON only, no other text: {"ytd_gross_earnings":number,"ytd_federal_tax_withheld":number}. IMPORTANT: ytd_federal_tax_withheld is ONLY Federal Income Tax withheld YTD (labeled Fed Tax, Federal Tax, Federal Income Tax, or FIT). Do NOT include Social Security tax, Medicare tax, state tax, or any other deductions. Use 0 if not found.'}]}]})})
      const data=await resp.json()
      const txt=data.content[0].text.replace(/```json/g,'').replace(/```/g,'').trim()
      const parsed=JSON.parse(txt)
      sf('w2',String(Math.round(parsed.ytd_gross_earnings||0)))
      sf('w2Withheld',String(Math.round(parsed.ytd_federal_tax_withheld||0)))
      setUploadMsg('Read: Wages $'+Math.round(parsed.ytd_gross_earnings).toLocaleString()+' | Withheld $'+Math.round(parsed.ytd_federal_tax_withheld).toLocaleString())
    }catch(err){setUploadMsg('Could not read paystub - please enter figures manually.')}
    setUploading(false)
  }
  const calc=()=>{const r=calcTax(nv(k1),f);setRes(r);setWhatIfOpen(false);setWifRes(null)}

  function saveRecord(){
    if(!recordName.trim())return
    const scenario={id:Date.now(),name:recordName.trim(),k1,f,res,date:new Date().toLocaleDateString()}
    const updated=[scenario,...savedRecords].slice(0,10)
    setSavedRecords(updated)
    localStorage.setItem('ts360_records',JSON.stringify(updated))
    setRecordName('');setShowSaveBox(false)
  }
  function loadRecord(s){
    setK1(s.k1);setF(s.f);setRes(s.res);setWhatIfOpen(false)
    window.scrollTo(0,0)
  }
  function deleteRecord(id){
    const updated=savedRecords.filter(s=>s.id!==id)
    setSavedRecords(updated)
    localStorage.setItem('ts360_records',JSON.stringify(updated))
  }
  function runWhatIf(){
    const merged={...f,...wif}
    const wk1=wif.k1!==undefined?wif.k1:k1
    setWifRes(calcTax(nv(wk1),merged))
  }
  const stdAmt=STD[f.filing]||STD.single
  const filingLabels={single:'Single',mfj:'Married Filing Jointly',mfs:'Married Filing Separately',hoh:'Head of Household',qss:'Qualifying Surviving Spouse'}
  return e('div',{style:{minHeight:'100vh',background:'#F8FAFC',fontFamily:'system-ui,sans-serif',color:N}},
    e('nav',{style:{background:'#fff',borderBottom:'1px solid #E2E8F0',padding:'0 32px',height:58,display:'flex',alignItems:'center',justifyContent:'space-between',position:'sticky',top:0,zIndex:200}},
      e('div',{style:{display:'flex',alignItems:'center',gap:10}},
        e('span',{style:{fontSize:18,fontWeight:800,color:N}},'TaxStat',e('span',{style:{color:B}},'360')),
        e('span',{style:{fontSize:11,background:'#EFF6FF',color:B,padding:'3px 10px',borderRadius:20,fontWeight:700}},'Step 2 of 2 - Form 1040')
      ),
      e('div',{style:{display:'flex',gap:8}},
        e('button',{onClick:()=>nav('/calculate-tax'),style:{padding:'6px 14px',background:'none',border:'1px solid #E2E8F0',borderRadius:7,fontSize:13,color:SL,cursor:'pointer'}},'Back to P&L'),
        e('button',{onClick:()=>{localStorage.clear();nav('/')},style:{padding:'6px 14px',background:'none',border:'1px solid #E2E8F0',borderRadius:7,fontSize:13,color:SL,cursor:'pointer'}},'Sign Out')
      )
    ),
    e('div',{style:{maxWidth:1180,margin:'0 auto',padding:'28px 20px'}},
      e('h1',{style:{fontSize:24,fontWeight:800,color:N,textAlign:'center',marginBottom:2}},'Personal Tax Return - Form 1040'),
      e('p',{style:{textAlign:'center',color:SL,fontSize:13,marginBottom:20}},'Click each section to expand - '+TAX_YR+' Tax Year - All IRS limits applied automatically'),
      e('div',{style:{background:'linear-gradient(135deg,#0D1B3E,#1e3a70)',borderRadius:12,padding:'16px 22px',marginBottom:20,display:'flex',alignItems:'center',justifyContent:'space-between'}},
        e('div',null,
          e('div',{style:{fontSize:11,color:'rgba(255,255,255,0.5)',marginBottom:3}},'K-1 PASS-THROUGH INCOME - FROM STEP 1'),
          e('div',{style:{fontSize:12,color:'rgba(255,255,255,0.6)'}},owns+'% ownership - Schedule E')
        ),
        e('div',{style:{textAlign:'right'}},
          e('div',{style:{fontSize:32,fontWeight:800,color:nv(k1)>=0?'#4ADE80':'#F87171'}},'$'+Math.abs(Math.round(nv(k1))||0).toLocaleString()),
          e('button',{onClick:()=>nav('/calculate-tax'),style:{fontSize:11,color:'rgba(255,255,255,0.4)',background:'none',border:'none',cursor:'pointer',marginTop:3,display:'block'}},'Edit business P&L')
        )
      ),
      e('div',{style:{display:'grid',gridTemplateColumns:'1fr 420px',gap:20,alignItems:'start'}},
        e('div',null,
          e(Section,{title:'Filing Status & Personal Info',icon:'1',open:true},
            Se('Filing Status',f.filing,v=>sf('filing',v),[
              ['single','Single'],['mfj','Married Filing Jointly'],['mfs','Married Filing Separately'],
              ['hoh','Head of Household'],['qss','Qualifying Surviving Spouse']
            ],'Form 1040, Line 1-5 (Filing Status). Your status is determined by your marital situation on December 31 of the tax year. Affects your standard deduction, tax brackets, and eligibility for certain credits.'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12,marginBottom:4}},
              Se('Qualifying Dependents',f.deps,v=>sf('deps',v),[['0','0'],['1','1'],['2','2'],['3','3'],['4','4'],['5','5'],['6','6+']],'Form 1040, Page 1 (Dependents section). List each qualifying child or relative. Used to calculate Child Tax Credit (Schedule 8812) and other family credits. Each must have a valid SSN.'),
              e('div',null,
                e('div',{style:{fontSize:12,fontWeight:700,color:SL,marginBottom:8}},'Additional Status'),
                Ck('Age 65 or older',f.age65,v=>sf('age65',v),'Form 1040, Page 1 (Standard Deduction checkbox). Check box if you or your spouse were born before January 2, 1960. Increases standard deduction by $1,550 (MFJ) or $1,950 (single/HOH) per person.'),
                Ck('Legally blind',f.blind,v=>sf('blind',v),'Form 1040, Page 1 (Standard Deduction checkbox). Check box if you or your spouse are legally blind. Increases standard deduction by $1,550 (MFJ) or $1,950 (single/HOH) per blind person.')
              )
            ),
            Se('Business Entity Type',f.entity,v=>sf('entity',v),[
              ['scorp','S-Corporation'],['mmllc','Multi-Member LLC'],['partnership','Partnership'],
              ['soleprop','Sole Proprietor'],['smllc','Single-Member LLC']
            ],'From your business formation documents or prior year Schedule K-1. S-Corp and partnership owners receive Schedule K-1. Sole proprietors use Schedule C. Determines SE Tax and QBI deduction eligibility.'),
            e('div',{style:{marginBottom:4}},
              e('div',{style:{display:'flex',alignItems:'center',marginBottom:5}},
                e('label',{style:{fontSize:12,fontWeight:700,color:SL}},'K-1 Income / Loss'),
                e(Tip,{text:'Schedule K-1 (Form 1065 for partnerships, Form 1120-S for S-Corps), Box 1 (Ordinary business income/loss). Pre-filled from Step 1 of TaxStat360. Flows to Schedule E, Part II.'})
              ),
              e('input',{value:k1,onChange:v=>setK1(v.target.value),type:'number',style:{width:'100%',padding:'10px 14px',border:'2px solid '+B,borderRadius:8,fontSize:15,boxSizing:'border-box',fontFamily:'inherit',background:'#EFF6FF',fontWeight:700}})
            )
          ),
          e(Section,{title:'W-2 Income & Withholding',icon:'2'},
            e('div',{style:{background:'#F8FAFC',borderRadius:10,padding:14,border:'2px dashed #E2E8F0',marginBottom:14,textAlign:'center'}},
              e('div',{style:{fontSize:13,fontWeight:700,color:N,marginBottom:3}},'Upload Most Recent Paystub (PDF)'),
              e('div',{style:{fontSize:11,color:SL,marginBottom:10}},'Auto-extracts YTD wages and federal withholding'),
              e('label',{style:{display:'inline-block',padding:'8px 20px',background:uploading?'#94A3B8':B,borderRadius:8,fontSize:13,fontWeight:700,color:'#fff',cursor:uploading?'not-allowed':'pointer'}},
                uploading?'Reading...':'Choose PDF',
                e('input',{type:'file',accept:'.pdf',onChange:handlePaystubUpload,disabled:uploading,style:{display:'none'}})
              ),
              uploadMsg&&e('div',{style:{marginTop:8,fontSize:12,color:uploadMsg.includes('Read:')?G:R,fontWeight:600}},uploadMsg)
            ),
            Fi('W-2 Wages, Salaries, Tips (YTD)',f.w2,v=>sf('w2',v),'Form W-2, Box 1 (Wages, tips, other compensation). If using a paystub, use the YTD Gross Earnings figure. If you have multiple employers, add all Box 1 amounts together.','0'),
            Fi('Federal Income Tax Withheld (YTD)',f.w2Withheld,v=>sf('w2Withheld',v),'Form W-2, Box 2 (Federal income tax withheld). On a paystub, look for the line labeled Federal Income Tax YTD. This is tax already withheld from paychecks and reduces what you owe.','0',true)
          ),
          e(Section,{title:'Other Income',icon:'3'},
            SubHead('INTEREST & DIVIDENDS'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('Taxable Interest Income',f.interest,v=>sf('interest',v),'Form 1099-INT, Box 1 (Interest income). Received from your bank, credit union, or brokerage each January. If interest is under $10, the institution may not send a 1099-INT but you must still report it.'),
              Fi('Ordinary Dividends',f.ordDiv,v=>sf('ordDiv',v),'Form 1099-DIV, Box 1a (Total ordinary dividends). Received from your brokerage each January. Add Box 1a amounts from all 1099-DIV forms you received.')
            ),
            Fi('Qualified Dividends',f.qualDiv,v=>sf('qualDiv',v),'Form 1099-DIV, Box 1b (Qualified dividends). This amount is already included in Box 1a above. It is taxed at lower preferential rates. Cannot be more than your ordinary dividends.'),
            Divider(),
            SubHead('CAPITAL GAINS & LOSSES'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('Short-Term Capital Gains/Losses',f.stcg,v=>sf('stcg',v),'Form 1099-B (from your broker) and Schedule D, Part I (Short-term transactions). Assets held 12 months or less. Losses are deductible up to $3,000 per year against ordinary income.'),
              Fi('Long-Term Capital Gains/Losses',f.ltcg,v=>sf('ltcg',v),'Form 1099-B (from your broker) and Schedule D, Part II (Long-term transactions). Assets held more than 12 months. Taxed at preferential rates of 0%, 15%, or 20% depending on income.')
            ),
            Divider(),
            SubHead('BUSINESS & RENTAL'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('Rental/Royalty Income (Net)',f.rental,v=>sf('rental',v),'Schedule E, Part I, Line 26 (Total rental real estate and royalty income or loss). This is your net figure after deducting allowable expenses. Can be a loss if expenses exceed rental income.'),
              Fi('1099-NEC / Self-Employment',f.nec,v=>sf('nec',v),'Form 1099-NEC, Box 1 (Nonemployee compensation). Received from clients who paid you $600 or more. If under $600, you may not receive a form but must still report the income.')
            ),
            Divider(),
            SubHead('RETIREMENT & SOCIAL SECURITY'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('Social Security Benefits (Total)',f.ssBenefits,v=>sf('ssBenefits',v),'Form SSA-1099 (Social Security Benefit Statement), Box 5 (Net benefits). Mailed by the Social Security Administration each January. Up to 85% may be taxable depending on your total income.'),
              Fi('Retirement Distributions (Taxable)',f.retirement,v=>sf('retirement',v),'Form 1099-R, Box 2a (Taxable amount). Received from your retirement plan administrator. Box 1 is the gross distribution, Box 2a is the taxable portion. Use Box 2a if known, otherwise Box 1.')
            ),
            Divider(),
            SubHead('OTHER'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('Alimony Received (Pre-2019 only)',f.alimonyRcvd,v=>sf('alimonyRcvd',v),'From your divorce or separation agreement and your own payment records. Only report if the agreement was finalized before January 1, 2019. Post-2018 agreements are not taxable.'),
              Fi('Other Taxable Income',f.otherInc,v=>sf('otherInc',v),'Schedule 1, Part I, Lines 1-8z (Additional income). Includes gambling winnings (Form W-2G), prizes (Form 1099-MISC Box 3), jury duty pay, hobby income, and other taxable income.')
            )
          ),
          e(Section,{title:'Above-the-Line Deductions (Schedule 1)',icon:'4'},
            e('div',{style:{background:'#EFF6FF',borderRadius:8,padding:'10px 14px',fontSize:12,color:'#1e40af',marginBottom:14}},'These reduce your AGI before standard/itemized deductions - use them even if you take the standard deduction.'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('Self-Employed Health Insurance',f.health,v=>sf('health',v),'Schedule 1, Part II, Line 17 (Self-employed health insurance deduction). Enter premiums paid for health, dental, and vision coverage. You must not be eligible for employer-subsidized coverage.'),
              e('div',null,
                Fi('HSA Contribution',f.hsa,v=>sf('hsa',v),'Form 8889, Line 2 (HSA contributions). Form 5498-SA is mailed by your HSA trustee. 2024 limits: $4,150 self-only, $8,300 family. Also shown on Schedule 1, Part II, Line 13.'),
                Ck('Family HSA coverage',f.hsaFamily,v=>sf('hsaFamily',v),'Check your HSA enrollment documents or Form 5498-SA to confirm your coverage type. Family coverage covers you plus at least one other person on a high-deductible health plan.')
              )
            ),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('SEP-IRA / Solo 401(k) Contribution',f.sep,v=>sf('sep',v),'Schedule 1, Part II, Line 16 (Self-employed SEP, SIMPLE, and qualified plans). Also shown on Form 5305-SEP or your plan records. Max: lesser of 25% of net SE income or $69,000 (2024).'),
              Fi('Student Loan Interest Paid',f.sl,v=>sf('sl',v),'Form 1098-E, Box 1 (Student loan interest received). Mailed by your loan servicer each January if you paid $600 or more in interest. Max deduction: $2,500. On Schedule 1, Part II, Line 21.')
            ),
            Fi('Alimony Paid (Pre-2019 agreements only)',f.alimonyPaid,v=>sf('alimonyPaid',v),'Schedule 1, Part II, Line 19a (Alimony paid). Enter the total paid and your former spouse SSN on Schedule 1 Line 19b. Only for agreements finalized before January 1, 2019.')
          ),
          e(Section,{title:'Prior Year Loss Carryforwards',icon:'5'},
            e('div',{style:{background:'#FFF7ED',borderRadius:8,padding:'10px 14px',fontSize:12,color:'#92400e',marginBottom:14}},'Prior year losses that carry forward to offset current year income. Find on your prior year tax return.'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('NOL Carryforward (Net Operating Loss)',f.nolCarry,v=>sf('nolCarry',v),'From your prior year Form 1040, Schedule 1, or Form 1045 (Application for Tentative Refund). Look for NOL carryover worksheets in your prior return. Post-2017 NOLs offset up to 80% of taxable income (IRC Section 172).'),
              Fi('QBI Loss Carryforward',f.qbiCarry,v=>sf('qbiCarry',v),'Form 8995, Line 3 (Prior year net QBI loss carryforward) or Form 8995-A, Schedule C. From your prior year tax return. This reduces your current year 20% QBI deduction under IRC Section 199A.')
            )
          ),
          e(Section,{title:'Itemized Deductions (Schedule A)',icon:'6'},
            e('div',{style:{background:'#FFF7ED',borderRadius:8,padding:'10px 14px',fontSize:12,color:'#92400e',marginBottom:14}},'We automatically compare your itemized total to the standard deduction ($'+stdAmt.toLocaleString()+' for '+filingLabels[f.filing]+') and use whichever is larger.'),
            SubHead('HOUSING'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('Mortgage Interest Paid',f.mortgageInt,v=>sf('mortgageInt',v),'Form 1098 (Mortgage Interest Statement), Box 1 (Mortgage interest received). Mailed by your lender each January. Deductible on acquisition debt up to $750,000 ($375,000 MFS). Schedule A, Line 8a.'),
              Fi('Property Taxes Paid',f.propTax,v=>sf('propTax',v),'Schedule A, Line 5b (State and local real estate taxes). Find on your county tax bill, mortgage statement (Form 1098, Box 10), or escrow summary. Combined SALT cap: $10,000 ($5,000 MFS) per IRC Section 164.')
            ),
            Fi('State & Local Income Tax (SALT)',f.stateIncomeTax,v=>sf('stateIncomeTax',v),'Schedule A, Line 5a (State and local income taxes). Find on your W-2 Box 17 (State income tax), your state tax return, or quarterly state estimated tax payment records. SALT cap: $10,000 combined.'),
            e('div',{style:{background:'#FEF3C7',borderRadius:8,padding:'8px 12px',fontSize:12,color:'#92400e',margin:'4px 0 12px'}},'SALT Cap: Property Tax + State Income Tax combined = max $10,000 deduction (IRC Section 164)'),
            Divider(),
            SubHead('CHARITABLE & MEDICAL'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('Charitable Contributions (Cash)',f.charitable,v=>sf('charitable',v),'Schedule A, Lines 11-12 (Gifts by cash or check). Keep written acknowledgment from the organization for any donation of $250 or more. Deduction limited to 60% of AGI for cash gifts.'),
              Fi('Medical & Dental Expenses (Total)',f.medical,v=>sf('medical',v),'Schedule A, Line 1 (Medical and dental expenses). Add up all unreimbursed expenses: insurance premiums, prescriptions, doctor and hospital bills, dental, vision, long-term care. Only amount above 7.5% of AGI is deductible.')
            ),
            e('div',{style:{background:'#EFF6FF',borderRadius:8,padding:'8px 12px',fontSize:12,color:'#1e40af',margin:'4px 0 4px'}},'Medical deduction = expenses minus 7.5% of AGI - Charitable capped at 60% of AGI - All limits applied automatically')
          ),
          e(Section,{title:'Tax Credits',icon:'7'},
            e('div',{style:{background:'#F0FDF4',borderRadius:8,padding:'10px 14px',fontSize:12,color:'#166534',marginBottom:14}},'Credits reduce your tax dollar-for-dollar - more valuable than deductions. All phase-outs and limits applied automatically.'),
            SubHead('FAMILY CREDITS'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              e('div',{style:{background:'#F8FAFC',borderRadius:10,padding:14,border:'1px solid #E2E8F0'}},
                e('div',{style:{display:'flex',alignItems:'center',marginBottom:4}},
                  e('div',{style:{fontSize:12,fontWeight:700,color:N}},'Child Tax Credit'),
                  e(Tip,{text:'Form 1040, Schedule 8812 (Credits for Qualifying Children and Other Dependents). $2,000 per qualifying child under age 17. Phases out $50 per $1,000 of AGI over $200,000 (single) or $400,000 (MFJ).'})
                ),
                e('div',{style:{fontSize:12,color:SL}},'Based on '+f.deps+' dependent(s) - phase-out applied automatically')
              ),
              Fi('Child & Dependent Care Expenses',f.careExp,v=>sf('careExp',v),'Form 2441 (Child and Dependent Care Expenses). Attach to Form 1040. Credit is 20%-35% of qualifying expenses up to $3,000 (1 qualifying person) or $6,000 (2 or more). Provider SSN or EIN required.')
            ),
            Divider(),
            SubHead('EDUCATION CREDITS'),
            e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
              Fi('American Opportunity Credit - Education Expenses',f.aocExp,v=>sf('aocExp',v),'Form 8863, Part I (American Opportunity Credit). Form 1098-T (Tuition Statement) is mailed by your school. Up to $2,500 credit (100% of first $2,000 + 25% of next $2,000). 40% is refundable. First 4 years of college only.'),
              Fi('Lifetime Learning Credit - Education Expenses',f.llcExp,v=>sf('llcExp',v),'Form 8863, Part II (Lifetime Learning Credit). Form 1098-T is mailed by your school. 20% of first $10,000 in qualified expenses = up to $2,000 per tax return (not per student). Not refundable.')
            ),
            Divider(),
            SubHead('RETIREMENT SAVINGS CREDIT'),
            Fi('IRA / 401(k) Contributions This Year',f.retContrib,v=>sf('retContrib',v),'Form 8880 (Credit for Qualified Retirement Savings Contributions). Credit is 10%-50% of contributions up to $2,000 ($4,000 MFJ). From your retirement account statements or Form 5498. Income limits apply.')
          ),
          e(Section,{title:'Taxes Already Paid',icon:'8'},
            e('div',{style:{background:'#F0FDF4',borderRadius:10,padding:14,border:'1px solid #BBF7D0',marginBottom:4}},
              e('div',{style:{fontSize:12,fontWeight:700,color:'#166534',marginBottom:12}},'These reduce your net amount owed dollar-for-dollar'),
              e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
                Fi('W-2 Federal Withholding YTD',f.w2Withheld,v=>sf('w2Withheld',v),'Form W-2, Box 2 (Federal income tax withheld). Auto-filled from paystub upload. If you have multiple W-2s, add all Box 2 amounts together. Also on Form 1040, Line 25a.','0',true),
                Fi('Estimated Tax Payments Made (YTD)',f.estPaid,v=>sf('estPaid',v),'Form 1040-ES payment vouchers or your IRS Online Account at irs.gov/account. Also on Form 1040, Line 26. Add all four quarterly payments made for the current tax year.','0',true)
              )
            )
          ),
          e('button',{onClick:calc,style:{width:'100%',padding:'16px',background:B,border:'none',borderRadius:12,fontSize:16,fontWeight:800,color:'#fff',cursor:'pointer',marginTop:8,fontFamily:'inherit',boxShadow:'0 4px 20px rgba(37,99,235,0.3)'}},'Calculate My '+TAX_YR+' Federal Tax Liability'),

          res&&e('div',{style:{marginTop:12}},
            !showSaveBox?e('button',{onClick:()=>setShowSaveBox(true),style:{width:'100%',padding:'10px',background:'#F0FDF4',border:'1px solid #BBF7D0',borderRadius:9,fontSize:13,fontWeight:700,color:'#166534',cursor:'pointer',fontFamily:'inherit'}},'Save This Record'):
            e('div',{style:{background:'#F0FDF4',borderRadius:10,padding:14,border:'1px solid #BBF7D0'}},
              e('div',{style:{fontSize:13,fontWeight:700,color:'#166534',marginBottom:8}},'Name this record'),
              e('div',{style:{display:'flex',gap:8}},
                e('input',{value:recordName,onChange:x=>setRecordName(x.target.value),placeholder:'e.g. Base Case 2026',onKeyDown:x=>x.key==='Enter'&&saveRecord(),style:{flex:1,padding:'8px 12px',border:'1px solid #86EFAC',borderRadius:7,fontSize:14,fontFamily:'inherit'}}),
                e('button',{onClick:saveRecord,style:{padding:'8px 16px',background:G,border:'none',borderRadius:7,fontSize:13,fontWeight:700,color:'#fff',cursor:'pointer',fontFamily:'inherit'}},'Save'),
                e('button',{onClick:()=>setShowSaveBox(false),style:{padding:'8px 12px',background:'none',border:'1px solid #E2E8F0',borderRadius:7,fontSize:13,color:SL,cursor:'pointer',fontFamily:'inherit'}},'Cancel')
              )
            )
          ),

          savedRecords.length>0&&e('div',{style:{marginTop:16}},
            e('div',{style:{fontSize:11,fontWeight:700,color:SL,letterSpacing:'1px',marginBottom:8}},'SAVED RECORDS'),
            e('div',{style:{display:'flex',flexDirection:'column',gap:6}},
              ...savedRecords.map(s=>
                e('div',{key:s.id,style:{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 14px',background:'#F8FAFC',borderRadius:9,border:'1px solid #E2E8F0'}},
                  e('div',null,
                    e('div',{style:{fontSize:13,fontWeight:700,color:N}},s.name),
                    e('div',{style:{fontSize:11,color:SL}},s.date+' - Tax: $'+(s.res?.grossTax||0).toLocaleString())
                  ),
                  e('div',{style:{display:'flex',gap:6}},
                    e('button',{onClick:()=>loadRecord(s),style:{padding:'5px 12px',background:B,border:'none',borderRadius:6,fontSize:12,fontWeight:700,color:'#fff',cursor:'pointer',fontFamily:'inherit'}},'Load'),
                    e('button',{onClick:()=>deleteRecord(s.id),style:{padding:'5px 10px',background:'none',border:'1px solid #FECACA',borderRadius:6,fontSize:12,color:R,cursor:'pointer',fontFamily:'inherit'}},'x')
                  )
                )
              )
            )
          )
        ),
        e('div',{style:{position:'sticky',top:70}},
          res?e('div',{style:{background:N,borderRadius:14,padding:22,color:'#fff'}},
            e('div',{style:{fontSize:10,fontWeight:700,color:'rgba(255,255,255,0.4)',letterSpacing:'1.5px',marginBottom:14}},TAX_YR+' FEDERAL TAX SUMMARY - FORM 1040'),
            e('div',{style:{textAlign:'center',padding:'16px 0',marginBottom:16,borderBottom:'1px solid rgba(255,255,255,0.1)'}},
              e('div',{style:{fontSize:11,color:'rgba(255,255,255,0.4)',marginBottom:2}},'Gross Tax Liability'),
              e('div',{style:{fontSize:40,fontWeight:800,color:'#F87171'}},fmt(res.grossTax)),
              e('div',{style:{fontSize:12,color:'rgba(255,255,255,0.4)',marginTop:3}},res.effRate+'% effective rate on AGI')
            ),
            e('div',{style:{fontSize:10,fontWeight:700,color:'rgba(255,255,255,0.3)',letterSpacing:'1px',marginBottom:8,paddingBottom:4,borderBottom:'1px solid rgba(255,255,255,0.08)'}},'INCOME'),
            Rw('Gross Income',fmt(res.grossIncome)),
            res.seDeduct>0&&Rw('1/2 SE Tax Deduction','-'+fmt(res.seDeduct),'#86EFAC',false,true),
            res.qbi>0&&Rw('QBI Deduction (20%)','-'+fmt(res.qbi),'#86EFAC',false,true),
            Rw('Adjusted Gross Income (AGI)',fmt(res.agi),'#FBBF24',true),
            e('div',{style:{fontSize:10,fontWeight:700,color:'rgba(255,255,255,0.3)',letterSpacing:'1px',margin:'10px 0 8px',paddingBottom:4,borderBottom:'1px solid rgba(255,255,255,0.08)'}},'DEDUCTION'),
            e('div',{style:{background:res.useItemized?'rgba(74,222,128,0.1)':'rgba(255,255,255,0.05)',borderRadius:7,padding:'8px 10px',marginBottom:6}},
              e('div',{style:{fontSize:11,color:res.useItemized?'#4ADE80':'rgba(255,255,255,0.5)',fontWeight:700,marginBottom:2}},res.useItemized?'Using Itemized Deductions':'Using Standard Deduction'),
              e('div',{style:{fontSize:12,color:'rgba(255,255,255,0.6)'}},res.useItemized?'Saves $'+res.deductionSavings.toLocaleString()+' vs standard':'Standard saves $'+res.deductionSavings.toLocaleString()+' vs your itemized total'),
              Rw('Deduction Applied','-'+fmt(res.deduction),'#86EFAC')
            ),
            res.nolDeduction>0&&Rw('NOL Carryforward Applied','-'+fmt(res.nolDeduction),'#86EFAC'),
          res.qbiCarryAmt>0&&Rw('QBI Loss Carryforward Applied','-'+fmt(res.qbiCarryAmt),'#86EFAC'),
          Rw('Federal Taxable Income',fmt(Math.max(0,res.agi-res.deduction-res.nolDeduction)),'#fff',true),
            e('div',{style:{fontSize:10,fontWeight:700,color:'rgba(255,255,255,0.3)',letterSpacing:'1px',margin:'10px 0 8px',paddingBottom:4,borderBottom:'1px solid rgba(255,255,255,0.08)'}},'TAX COMPONENTS'),
            Rw('Federal Income Tax (Ordinary)',fmt(res.fedOrd),'#F87171'),
            res.fedLTCG>0&&Rw('Tax on LTCG / Qualified Divs',fmt(res.fedLTCG),'#F87171'),
            res.seTax>0&&Rw('Self-Employment Tax (15.3%)',fmt(res.seTax),'#F87171'),
            res.niit>0&&Rw('Net Investment Income Tax (3.8%)',fmt(res.niit),'#F87171'),
            res.totalCredits>0&&e('div',null,
              e('div',{style:{fontSize:10,fontWeight:700,color:'rgba(255,255,255,0.3)',letterSpacing:'1px',margin:'10px 0 8px',paddingBottom:4,borderBottom:'1px solid rgba(255,255,255,0.08)'}},'CREDITS APPLIED'),
              res.ctc>0&&Rw('Child Tax Credit','-'+fmt(res.ctc),'#86EFAC'),
              res.careCred>0&&Rw('Child & Dependent Care','-'+fmt(res.careCred),'#86EFAC'),
              res.aoc>0&&Rw('American Opportunity Credit','-'+fmt(res.aoc),'#86EFAC'),
              res.llc>0&&Rw('Lifetime Learning Credit','-'+fmt(res.llc),'#86EFAC'),
              res.savers>0&&Rw('Savers Credit','-'+fmt(res.savers),'#86EFAC')
            ),
            e('div',{style:{display:'flex',justifyContent:'space-between',padding:'8px 0',margin:'6px 0',borderTop:'1px solid rgba(255,255,255,0.15)',borderBottom:'1px solid rgba(255,255,255,0.15)'}},
              e('span',{style:{fontSize:14,fontWeight:700}},'Gross Tax Liability'),
              e('span',{style:{fontSize:18,fontWeight:800,color:'#F87171'}},fmt(res.grossTax))
            ),
            e('div',{style:{fontSize:10,fontWeight:700,color:'rgba(255,255,255,0.3)',letterSpacing:'1px',margin:'10px 0 8px',paddingBottom:4,borderBottom:'1px solid rgba(255,255,255,0.08)'}},'TAXES ALREADY PAID'),
            res.w2Withheld>0&&Rw('W-2 Federal Withholding','-'+fmt(res.w2Withheld),'#86EFAC'),
            res.estPaid>0&&Rw('Estimated Tax Payments','-'+fmt(res.estPaid),'#86EFAC'),
            e('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'14px 16px',margin:'10px 0 6px',borderRadius:10,background:res.refund>0?'rgba(74,222,128,0.15)':'rgba(248,113,113,0.15)',border:'1px solid '+(res.refund>0?'rgba(74,222,128,0.4)':'rgba(248,113,113,0.4)')}},
              e('span',{style:{fontSize:14,fontWeight:800,color:res.refund>0?'#4ADE80':'#F87171'}},res.refund>0?'Estimated Refund':'Net Amount Owed'),
              e('span',{style:{fontSize:22,fontWeight:800,color:res.refund>0?'#4ADE80':'#F87171'}},fmt(res.refund>0?res.refund:res.netOwed))
            ),
            res.netOwed>0&&e('div',null,
              e('div',{style:{fontSize:10,fontWeight:700,color:'rgba(255,255,255,0.3)',letterSpacing:'1px',margin:'12px 0 8px',paddingBottom:4,borderBottom:'1px solid rgba(255,255,255,0.08)'}},'REMAINING QUARTERLY ESTIMATES - IRS 1040-ES'),
              e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:14}},
                ...['Q1 Apr 15','Q2 Jun 17','Q3 Sep 16','Q4 Jan 15'].map((d,i)=>
                  e('div',{key:i,style:{background:'rgba(255,255,255,0.07)',borderRadius:8,padding:'9px 12px'}},
                    e('div',{style:{fontSize:10,color:'rgba(255,255,255,0.4)',marginBottom:2}},d),
                    e('div',{style:{fontSize:15,fontWeight:700,color:GOLD}},fmt(res.qtr))
                  )
                )
              )
            ),
            e('div',{style:{background:'rgba(74,222,128,0.1)',border:'1px solid rgba(74,222,128,0.2)',borderRadius:8,padding:'10px 14px',fontSize:12,color:'#4ADE80',textAlign:'center',marginBottom:10}},'AI Tax Advisor can show you strategies to reduce this '+fmt(res.grossTax)+' liability'),
            e('button',{onClick:()=>nav('/ai-analysis'),style:{width:'100%',padding:'10px',background:B,border:'none',borderRadius:8,fontSize:14,fontWeight:700,color:'#fff',cursor:'pointer',fontFamily:'inherit',marginBottom:8}},'View AI Tax Strategies'),
            e('button',{onClick:()=>setWhatIfOpen(o=>!o),style:{width:'100%',padding:'10px',background:'rgba(255,255,255,0.1)',border:'1px solid rgba(255,255,255,0.2)',borderRadius:8,fontSize:14,fontWeight:700,color:'#fff',cursor:'pointer',fontFamily:'inherit'}},whatIfOpen?'Close What-If Simulator':'What-If Simulator'),
            whatIfOpen&&e('div',{style:{marginTop:12,background:'rgba(255,255,255,0.05)',borderRadius:10,padding:14}},
              e('div',{style:{fontSize:11,fontWeight:700,color:'rgba(255,255,255,0.5)',letterSpacing:'1px',marginBottom:10}},'CHANGE A VARIABLE - SEE THE IMPACT'),
              e('div',{style:{marginBottom:8}},
                e('label',{style:{fontSize:11,color:'rgba(255,255,255,0.6)',display:'block',marginBottom:4}},'SEP-IRA / 401(k) Contribution'),
                e('input',{type:'number',placeholder:f.sep||'0',onChange:x=>setWif(p=>({...p,sep:x.target.value})),style:{width:'100%',padding:'8px 10px',borderRadius:7,border:'1px solid rgba(255,255,255,0.2)',background:'rgba(255,255,255,0.1)',color:'#fff',fontSize:13,boxSizing:'border-box',fontFamily:'inherit'}})
              ),
              e('div',{style:{marginBottom:8}},
                e('label',{style:{fontSize:11,color:'rgba(255,255,255,0.6)',display:'block',marginBottom:4}},'Filing Status'),
                e('select',{value:wif.filing||f.filing,onChange:x=>setWif(p=>({...p,filing:x.target.value})),style:{width:'100%',padding:'8px 10px',borderRadius:7,border:'1px solid rgba(255,255,255,0.2)',background:'#1E293B',color:'#fff',fontSize:13,fontFamily:'inherit'}},
                  e('option',{value:'single'},'Single'),
                  e('option',{value:'mfj'},'Married Filing Jointly'),
                  e('option',{value:'mfs'},'Married Filing Separately'),
                  e('option',{value:'hoh'},'Head of Household')
                )
              ),
              e('div',{style:{marginBottom:8}},
                e('label',{style:{fontSize:11,color:'rgba(255,255,255,0.6)',display:'block',marginBottom:4}},'Mortgage Interest'),
                e('input',{type:'number',placeholder:f.mortgageInt||'0',onChange:x=>setWif(p=>({...p,mortgageInt:x.target.value})),style:{width:'100%',padding:'8px 10px',borderRadius:7,border:'1px solid rgba(255,255,255,0.2)',background:'rgba(255,255,255,0.1)',color:'#fff',fontSize:13,boxSizing:'border-box',fontFamily:'inherit'}})
              ),
              e('div',{style:{marginBottom:8}},
                e('label',{style:{fontSize:11,color:'rgba(255,255,255,0.6)',display:'block',marginBottom:4}},'Charitable Contributions'),
                e('input',{type:'number',placeholder:f.charitable||'0',onChange:x=>setWif(p=>({...p,charitable:x.target.value})),style:{width:'100%',padding:'8px 10px',borderRadius:7,border:'1px solid rgba(255,255,255,0.2)',background:'rgba(255,255,255,0.1)',color:'#fff',fontSize:13,boxSizing:'border-box',fontFamily:'inherit'}})
              ),
              e('div',{style:{marginBottom:10}},
                e('label',{style:{fontSize:11,color:'rgba(255,255,255,0.6)',display:'block',marginBottom:4}},'K-1 Income (override)'),
                e('input',{type:'number',placeholder:k1||'0',onChange:x=>setWif(p=>({...p,k1:x.target.value})),style:{width:'100%',padding:'8px 10px',borderRadius:7,border:'1px solid rgba(255,255,255,0.2)',background:'rgba(255,255,255,0.1)',color:'#fff',fontSize:13,boxSizing:'border-box',fontFamily:'inherit'}})
              ),
              e('button',{onClick:runWhatIf,style:{width:'100%',padding:'10px',background:'#FBBF24',border:'none',borderRadius:8,fontSize:13,fontWeight:800,color:'#000',cursor:'pointer',fontFamily:'inherit'}},'Calculate What-If'),
              wifRes&&e('div',{style:{marginTop:12}},
                e('div',{style:{fontSize:11,fontWeight:700,color:'rgba(255,255,255,0.4)',letterSpacing:'1px',marginBottom:8}},'COMPARISON'),
                e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:8}},
                  e('div',{style:{background:'rgba(248,113,113,0.15)',borderRadius:8,padding:'10px 12px',textAlign:'center'}},
                    e('div',{style:{fontSize:10,color:'rgba(255,255,255,0.4)',marginBottom:3}},'CURRENT'),
                    e('div',{style:{fontSize:20,fontWeight:800,color:'#F87171'}},fmt(res.grossTax))
                  ),
                  e('div',{style:{background:'rgba(74,222,128,0.15)',borderRadius:8,padding:'10px 12px',textAlign:'center'}},
                    e('div',{style:{fontSize:10,color:'rgba(255,255,255,0.4)',marginBottom:3}},'WHAT-IF'),
                    e('div',{style:{fontSize:20,fontWeight:800,color:'#4ADE80'}},fmt(wifRes.grossTax))
                  )
                ),
                res.grossTax-wifRes.grossTax>0?
                  e('div',{style:{background:'rgba(74,222,128,0.15)',border:'1px solid rgba(74,222,128,0.3)',borderRadius:8,padding:'10px 14px',textAlign:'center'}},
                    e('div',{style:{fontSize:12,color:'#4ADE80',fontWeight:700}},'You would SAVE '+fmt(res.grossTax-wifRes.grossTax)+' in taxes')
                  ):
                  e('div',{style:{background:'rgba(248,113,113,0.15)',border:'1px solid rgba(248,113,113,0.3)',borderRadius:8,padding:'10px 14px',textAlign:'center'}},
                    e('div',{style:{fontSize:12,color:'#F87171',fontWeight:700}},'Tax increases by '+fmt(wifRes.grossTax-res.grossTax))
                  )
              )
            )
          ):e('div',{style:{background:'#fff',borderRadius:14,padding:32,border:'1px solid #E2E8F0',textAlign:'center'}},
            e('div',{style:{fontSize:44,marginBottom:12}},'[1040]'),
            e('div',{style:{fontSize:15,fontWeight:700,color:N,marginBottom:8}},'Your tax summary appears here'),
            e('div',{style:{fontSize:13,color:SL,lineHeight:1.8}},'Expand any section on the left, fill in your details, then click Calculate')
          )
        )
      )
    )
  )
}