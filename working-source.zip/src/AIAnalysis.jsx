import React from 'react'
import{useNavigate}from 'react-router-dom'
const e=React.createElement
const N='#0D1B3E',B='#2563EB',SL='#475569',G='#16a34a'
const API='https://05madmjrqd.execute-api.us-east-1.amazonaws.com/prod/paystub'

const SUGGESTED=[
  'How can I reduce my self-employment tax?',
  'Should I convert to an S-Corp to save on taxes?',
  'What deductions am I likely missing?',
  'How much should I contribute to my SEP-IRA to lower my tax bill?',
  'What are my audit risks based on my return?',
  'How can I use my rental property to reduce my taxes?',
  'What entity structure would save me the most in taxes?',
  'What are the tax benefits of a home office deduction?'
]

function buildSystemPrompt(ctx){
  return `You are an expert AI Tax Advisor for TaxStat360, a real-time tax liability calculator for business owners. You provide specific, actionable tax strategy advice.

${ctx.hasData?`CLIENT TAX PROFILE (from their completed return):
- Entity Type: ${ctx.entity||'Not specified'}
- K-1 / Business Income: ${ctx.k1?'$'+Math.abs(ctx.k1).toLocaleString():'Not entered'}
- W-2 Wages: ${ctx.w2?'$'+Number(ctx.w2).toLocaleString():'None'}
- Filing Status: ${ctx.filing||'Single'}
- AGI: ${ctx.agi?'$'+Math.abs(ctx.agi).toLocaleString():'Not calculated'}
- Gross Tax Liability: ${ctx.tax?'$'+ctx.tax.toLocaleString():'Not calculated'}
- Effective Tax Rate: ${ctx.rate||'0'}%
- SE Tax Paid: ${ctx.seTax?'$'+ctx.seTax.toLocaleString():'None'}
- QBI Deduction Taken: ${ctx.qbi?'$'+ctx.qbi.toLocaleString():'None'}
- Itemized Deductions: ${ctx.itemized?'$'+ctx.itemized.toLocaleString()+' ('+ctx.dedType+')':(ctx.dedType||'Standard deduction')}
- Rental Income: ${ctx.rental?'$'+Number(ctx.rental).toLocaleString():'None'}
- Dependents: ${ctx.deps||'0'}
- Estimated Quarterly Tax: ${ctx.qtr?'$'+ctx.qtr.toLocaleString()+'/quarter':'Not calculated'}`:
'CLIENT PROFILE: The client has not yet completed their tax return. Provide general guidance and encourage them to complete Step 1 (Business Income) and Step 2 (Form 1040) for personalized advice.'}

YOUR PERSONA:
You are Aria, TaxStat360's expert AI Tax Advisor. You are knowledgeable, direct, and genuinely helpful. You speak like a trusted CPA friend — confident, specific, and never vague. You always personalize advice to the client's actual numbers.

YOUR ROLE:
- Provide specific, personalized tax strategies based on the client data above
- Always cite the relevant IRC section, form, or IRS publication when recommending strategies
- Quantify savings when possible (e.g., "This could save you approximately $X")
- Be direct and actionable — not generic
- Flag any audit risks you identify based on their profile
- Never give legal advice but always recommend consulting a CPA for implementation
- Format responses clearly with specific action items

IMPORTANT: Always reference their actual numbers when they exist. Be a knowledgeable advisor, not a generic chatbot.`
}

// AUDIT RISK ANALYZER - Add to AIAnalysis.jsx as a tab or separate section

const AUDIT_RULES = [
  {
    id:'high_charitable',
    category:'Charitable Deductions',
    check:(ctx)=>ctx.charitable>0&&ctx.agi>0&&(ctx.charitable/ctx.agi)>0.05,
    severity:(ctx)=>(ctx.charitable/ctx.agi)>0.10?'HIGH':'MEDIUM',
    title:'Charitable Deductions Above Average',
    detail:(ctx)=>`Your charitable deductions of $${ctx.charitable?.toLocaleString()} represent ${Math.round((ctx.charitable/ctx.agi)*100)}% of your AGI. The IRS average for your income level is 2-3%. Amounts above 5% are a known audit trigger.`,
    action:'Ensure you have written acknowledgment from each charity for donations over $250. Keep bank records, credit card statements, and Form 8283 for non-cash donations over $500.'
  },
  {
    id:'home_office',
    category:'Business Use of Home',
    check:(ctx)=>ctx.entity==='soleprop'||ctx.entity==='smllc',
    severity:()=>'MEDIUM',
    title:'Home Office Deduction Eligibility',
    detail:()=>'Schedule C filers claiming home office deductions are audited at higher rates. The IRS scrutinizes whether the space is used regularly and exclusively for business.',
    action:'Calculate using the simplified method ($5/sq ft, max 300 sq ft = $1,500 max) or actual expenses. Keep a floor plan showing dedicated office space. Document exclusive business use.'
  },
  {
    id:'high_meals',
    category:'Business Meals & Entertainment',
    check:(ctx)=>ctx.entity!==null&&ctx.k1>50000,
    severity:()=>'LOW',
    title:'Business Meals Deduction',
    detail:()=>'Post-TCJA, only 50% of business meals are deductible. Entertainment expenses are no longer deductible. The IRS looks for proper documentation of who, what, when, and business purpose.',
    action:'For each meal: document the business purpose, attendees, and relationship to business. Keep receipts for all meals over $75. Separate meals from entertainment on your records.'
  },
  {
    id:'scorp_salary',
    category:'S-Corp Reasonable Compensation',
    check:(ctx)=>ctx.entity==='scorp'&&ctx.k1>0,
    severity:(ctx)=>ctx.w2<ctx.k1*0.3?'HIGH':'LOW',
    title:(ctx)=>ctx.w2<ctx.k1*0.3?'S-Corp Salary May Be Too Low':'S-Corp Reasonable Compensation',
    detail:(ctx)=>`Your W-2 salary of $${ctx.w2?.toLocaleString()} vs K-1 distributions of $${ctx.k1?.toLocaleString()}. ${ctx.w2<ctx.k1*0.3?'The IRS requires S-Corp owners to pay themselves a "reasonable salary" before taking distributions. Your salary appears low relative to distributions, which is a top audit trigger.':'Your salary ratio looks reasonable relative to your distributions.'}`,
    action:'Document your salary using industry salary surveys (BLS, salary.com, RCReports). Your salary should reflect what you would pay an employee to do your job. Keep board minutes authorizing the salary.'
  },
  {
    id:'large_cash',
    category:'Cash Business Reporting',
    check:(ctx)=>ctx.entity==='soleprop'||ctx.entity==='smllc',
    severity:()=>'MEDIUM',
    title:'Cash Business Income Reporting',
    detail:()=>'Schedule C businesses with high gross receipts and low net income are frequently audited. The IRS compares reported income against lifestyle indicators and industry averages.',
    action:'Report all income including cash payments. Maintain a separate business bank account. Deposit all business income. Keep invoices, receipts, and a mileage log.'
  },
  {
    id:'high_nol',
    category:'Net Operating Loss',
    check:(ctx)=>ctx.nolCarry>0,
    severity:(ctx)=>ctx.nolCarry>50000?'HIGH':'MEDIUM',
    title:'NOL Carryforward Applied',
    detail:(ctx)=>`You applied a $${ctx.nolCarry?.toLocaleString()} NOL carryforward. Large NOL deductions are reviewed carefully, especially when they significantly reduce tax liability.`,
    action:'Retain all documentation from the loss year: tax returns, financial statements, and worksheets showing the NOL calculation. Post-2017 NOLs must be tracked separately (80% of taxable income limit).'
  },
  {
    id:'rental_losses',
    category:'Rental Property Losses',
    check:(ctx)=>ctx.rental<0,
    severity:(ctx)=>ctx.rental<-25000?'HIGH':'MEDIUM',
    title:'Rental Property Loss Deduction',
    detail:(ctx)=>`Your rental property shows a loss of $${Math.abs(ctx.rental)?.toLocaleString()}. Passive activity loss rules (IRC §469) limit rental losses to $25,000 for active participants (phasing out between $100K-$150K AGI). Larger losses require Real Estate Professional status.`,
    action:'Document your hours spent on rental activities. If claiming Real Estate Professional status (750+ hours, more than 50% of working time), maintain a detailed time log. Keep all expense receipts.'
  },
  {
    id:'high_auto',
    category:'Vehicle Business Use',
    check:(ctx)=>ctx.entity!==null&&ctx.k1>0,
    severity:()=>'MEDIUM',
    title:'Business Vehicle Deduction',
    detail:()=>'Vehicle deductions are one of the most commonly audited items for self-employed individuals. The IRS looks for proper mileage logs and business purpose documentation.',
    action:'Maintain a contemporaneous mileage log showing: date, destination, business purpose, and miles. Use apps like MileIQ or TripLog. Never claim 100% business use without strong documentation.'
  },
  {
    id:'se_tax_reduction',
    category:'Self-Employment Tax',
    check:(ctx)=>(ctx.entity==='soleprop'||ctx.entity==='smllc')&&ctx.k1>40000,
    severity:()=>'LOW',
    title:'SE Tax Optimization Opportunity',
    detail:(ctx)=>`You paid $${ctx.seTax?.toLocaleString()} in self-employment tax (15.3%). S-Corp election could reduce this significantly on your $${ctx.k1?.toLocaleString()} in net income.`,
    action:'Consider S-Corp election if net profit exceeds $40,000 consistently. The tax savings on distributions (not subject to SE tax) can outweigh S-Corp administrative costs (~$2,000-3,000/year).'
  },
  {
    id:'salt_cap',
    category:'SALT Deduction Cap',
    check:(ctx)=>ctx.itemized>0&&ctx.salt>=10000,
    severity:()=>'LOW',
    title:'SALT Deduction Capped at $10,000',
    detail:()=>'Your state and local taxes hit the $10,000 SALT cap (IRC §164). This is correctly applied but worth noting for state tax planning.',
    action:'Consider prepaying property taxes in years when itemizing provides more benefit. Some states offer SALT workarounds through pass-through entity taxes (PTET elections) that can bypass the cap.'
  }
]

const SEVERITY_CONFIG = {
  HIGH:   { color:'#DC2626', bg:'#FEF2F2', border:'#FECACA', icon:'!', label:'HIGH RISK' },
  MEDIUM: { color:'#D97706', bg:'#FFFBEB', border:'#FDE68A', icon:'~', label:'MEDIUM RISK' },
  LOW:    { color:'#2563EB', bg:'#EFF6FF', border:'#BFDBFE', icon:'i', label:'OPPORTUNITY' }
}

function AuditRiskAnalyzer({ctx}){
  const[expanded,setExpanded]=React.useState({})
    const N='#0D1B3E',SL='#475569'

  if(!ctx.hasData){
    return e('div',{style:{background:'#FFF7ED',borderRadius:12,padding:24,border:'1px solid #FED7AA',textAlign:'center'}},
      e('div',{style:{fontSize:32,marginBottom:8}},'[!]'),
      e('div',{style:{fontSize:15,fontWeight:700,color:N,marginBottom:4}},'Complete Your Return First'),
      e('div',{style:{fontSize:13,color:SL}},'Aria needs your tax data to analyze your audit risk. Complete Steps 1 and 2 first.')
    )
  }

  const flags = AUDIT_RULES.filter(rule=>rule.check(ctx))
  const highCount = flags.filter(f=>f.severity(ctx)==='HIGH').length
  const medCount = flags.filter(f=>f.severity(ctx)==='MEDIUM').length
  const lowCount = flags.filter(f=>f.severity(ctx)==='LOW').length

  const riskScore = Math.min(100, (highCount*30)+(medCount*15)+(lowCount*5))
  const riskLabel = riskScore>=60?'HIGH':riskScore>=30?'MODERATE':'LOW'
  const riskColor = riskScore>=60?'#DC2626':riskScore>=30?'#D97706':'#16a34a'

  return e('div',null,
    // Overall risk score
    e('div',{style:{background:'linear-gradient(135deg,#0D1B3E,#1e3a70)',borderRadius:14,padding:24,marginBottom:20,color:'#fff'}},
      e('div',{style:{fontSize:11,color:'rgba(255,255,255,0.5)',letterSpacing:'1px',marginBottom:12}},'AUDIT RISK ASSESSMENT'),
      e('div',{style:{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:16}},
        e('div',null,
          e('div',{style:{fontSize:48,fontWeight:800,color:riskColor}},riskScore),
          e('div',{style:{fontSize:13,color:'rgba(255,255,255,0.6)'}},'out of 100 risk score')
        ),
        e('div',{style:{textAlign:'right'}},
          e('div',{style:{fontSize:24,fontWeight:800,color:riskColor,marginBottom:4}},riskLabel+' RISK'),
          e('div',{style:{fontSize:12,color:'rgba(255,255,255,0.5)'}},flags.length+' items flagged for review')
        )
      ),
      e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10}},
        e('div',{style:{background:'rgba(220,38,38,0.2)',borderRadius:8,padding:'10px 14px',textAlign:'center',border:'1px solid rgba(220,38,38,0.3)'}},
          e('div',{style:{fontSize:24,fontWeight:800,color:'#F87171'}},highCount),
          e('div',{style:{fontSize:11,color:'rgba(255,255,255,0.5)'}},'\u26A0 High Risk')
        ),
        e('div',{style:{background:'rgba(217,119,6,0.2)',borderRadius:8,padding:'10px 14px',textAlign:'center',border:'1px solid rgba(217,119,6,0.3)'}},
          e('div',{style:{fontSize:24,fontWeight:800,color:'#FCD34D'}},medCount),
          e('div',{style:{fontSize:11,color:'rgba(255,255,255,0.5)'}},'~ Medium Risk')
        ),
        e('div',{style:{background:'rgba(37,99,235,0.2)',borderRadius:8,padding:'10px 14px',textAlign:'center',border:'1px solid rgba(37,99,235,0.3)'}},
          e('div',{style:{fontSize:24,fontWeight:800,color:'#93C5FD'}},lowCount),
          e('div',{style:{fontSize:11,color:'rgba(255,255,255,0.5)'}},'\u2139 Opportunities')
        )
      )
    ),

    // Individual flags
    e('div',{style:{display:'flex',flexDirection:'column',gap:10}},
      ...flags.map(flag=>{
        const sev=flag.severity(ctx)
        const cfg=SEVERITY_CONFIG[sev]
        const isOpen=expanded[flag.id]
        const title=typeof flag.title==='function'?flag.title(ctx):flag.title
        const detail=typeof flag.detail==='function'?flag.detail(ctx):flag.detail
        return e('div',{key:flag.id,style:{background:cfg.bg,borderRadius:12,border:'1px solid '+cfg.border,overflow:'hidden'}},
          e('div',{onClick:()=>setExpanded(p=>({...p,[flag.id]:!p[flag.id]})),
            style:{padding:'14px 18px',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'space-between'}},
            e('div',{style:{display:'flex',alignItems:'center',gap:12}},
              e('div',{style:{width:28,height:28,borderRadius:'50%',background:cfg.color,color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,fontWeight:800,flexShrink:0}},cfg.icon),
              e('div',null,
                e('div',{style:{fontSize:13,fontWeight:700,color:N}},title),
                e('div',{style:{fontSize:11,color:SL}},flag.category+' - '+cfg.label)
              )
            ),
            e('span',{style:{color:cfg.color,fontSize:18,transform:isOpen?'rotate(180deg)':'none',transition:'transform 0.2s'}},'v')
          ),
          isOpen&&e('div',{style:{padding:'0 18px 16px',borderTop:'1px solid '+cfg.border}},
            e('div',{style:{fontSize:13,color:N,lineHeight:1.7,marginBottom:12,marginTop:12}},detail),
            e('div',{style:{background:'#fff',borderRadius:8,padding:'10px 14px',border:'1px solid '+cfg.border}},
              e('div',{style:{fontSize:11,fontWeight:700,color:cfg.color,marginBottom:4}},'RECOMMENDED ACTION'),
              e('div',{style:{fontSize:12,color:N,lineHeight:1.6}},flag.action)
            )
          )
        )
      })
    ),
    e('div',{style:{marginTop:16,padding:'12px 16px',background:'#F8FAFC',borderRadius:10,fontSize:12,color:SL,textAlign:'center',border:'1px solid #E2E8F0'}},
      'Audit risk analysis is based on known IRS selection criteria and statistical averages. Individual risk varies. Consult a licensed CPA for a comprehensive review.'
    )
  )
}

export default function AIAnalysis(){
  const nav=useNavigate()
  const[messages,setMessages]=React.useState([])
  const[input,setInput]=React.useState('')
  const[loading,setLoading]=React.useState(false)
  const[activeTab,setActiveTab]=React.useState('aria')
  const endRef=React.useRef(null)

  // Load tax context from session/localStorage
  const ctx=React.useMemo(()=>{
    try{
      const k1=sessionStorage.getItem('ts360_k1')
      const entities=JSON.parse(sessionStorage.getItem('ts360_entities')||'[]')
      const entity=entities[0]?.entityType||'scorp'
      const lastRes=JSON.parse(localStorage.getItem('ts360_last_result')||'null')
      if(lastRes){
        return{
          hasData:true,entity,k1:Number(k1||0),
          w2:lastRes.w2||0,filing:lastRes.filing||'single',
          agi:lastRes.agi||0,tax:lastRes.grossTax||0,
          rate:lastRes.effRate||'0',seTax:lastRes.seTax||0,
          qbi:lastRes.qbi||0,itemized:lastRes.itemized||0,
          dedType:lastRes.useItemized?'Itemized':'Standard',
          rental:lastRes.rental||0,deps:lastRes.deps||0,
          qtr:lastRes.qtr||0
        }
      }
      if(k1){return{hasData:true,entity,k1:Number(k1),w2:0,filing:'single',agi:0,tax:0,rate:'0',seTax:0,qbi:0,itemized:0,dedType:'Standard',rental:0,deps:0,qtr:0}}
      return{hasData:false}
    }catch{return{hasData:false}}
  },[])

  React.useEffect(()=>{
    // Welcome message
    const welcome = ctx.hasData
      ? `Hi, I'm **Aria**, your personal AI Tax Advisor.\n\nI can see your tax profile — ${ctx.entity==='scorp'?'S-Corporation':ctx.entity==='smllc'?'Single-Member LLC':ctx.entity} with ${ctx.k1?'$'+Math.abs(ctx.k1).toLocaleString()+' in K-1 income':' business income on file'}${ctx.tax?', a $'+ctx.tax.toLocaleString()+' tax liability':''}, and a ${ctx.rate}% effective rate.\n\nI can help you identify strategies to legally reduce your tax bill, analyze your audit risk, optimize your entity structure, and more. What would you like to explore?`
      : `Hi, I'm **Aria**, your personal AI Tax Advisor.\n\nTo get personalized advice based on your actual numbers, please complete **Step 1 (Business Income)** and **Step 2 (Form 1040)** first.\n\nIn the meantime, I can answer general tax strategy questions. What would you like to know?`
    setMessages([{role:'assistant',content:welcome}])
  },[])

  React.useEffect(()=>{
    endRef.current?.scrollIntoView({behavior:'smooth'})
  },[messages])

  async function send(text){
    const q=(text||input).trim()
    if(!q||loading)return
    setInput('')
    const userMsg={role:'user',content:q}
    setMessages(p=>[...p,userMsg])
    setLoading(true)
    try{
      const history=messages.filter(m=>m.role!=='system').slice(-10).map(m=>({role:m.role,content:m.content}))
      const resp=await fetch(API,{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
          system:buildSystemPrompt(ctx),
          messages:[...history,{role:'user',content:q}]
        })
      })
      const data=await resp.json()
      const reply=data.content?.[0]?.text||'I encountered an issue. Please try again.'
      setMessages(p=>[...p,{role:'assistant',content:reply}])
    }catch(err){
      setMessages(p=>[...p,{role:'assistant',content:'Connection error. Please try again.'}])
    }
    setLoading(false)
  }

  function renderContent(text){
    // Simple markdown-like rendering
    return text.split('\n').map((line,i)=>{
      if(line.startsWith('**')&&line.endsWith('**'))
        return e('div',{key:i,style:{fontWeight:700,color:N,marginBottom:4}},line.slice(2,-2))
      if(line.startsWith('- '))
        return e('div',{key:i,style:{display:'flex',gap:8,marginBottom:3,paddingLeft:8}},
          e('span',{style:{color:B,fontWeight:700,flexShrink:0}},'•'),
          e('span',null,line.slice(2))
        )
      if(line.match(/^\d+\./))
        return e('div',{key:i,style:{display:'flex',gap:8,marginBottom:3,paddingLeft:8}},
          e('span',{style:{color:B,fontWeight:700,flexShrink:0}},line.match(/^\d+\./)[0]),
          e('span',null,line.replace(/^\d+\.\s*/,''))
        )
      if(line==='')return e('div',{key:i,style:{height:6}})
      // Handle inline **bold**
      const parts=line.split(/\*\*([^*]+)\*\*/)
      if(parts.length>1)
        return e('div',{key:i,style:{marginBottom:2}},
          ...parts.map((p,j)=>j%2===0?p:e('strong',{key:j},p))
        )
      return e('div',{key:i,style:{marginBottom:2}},line)
    })
  }

  return e('div',{style:{minHeight:'100vh',background:'#F8FAFC',fontFamily:'system-ui,sans-serif',color:N,display:'flex',flexDirection:'column'}},
    // NAV
    e('nav',{style:{background:'#fff',borderBottom:'1px solid #E2E8F0',padding:'0 32px',height:58,display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0}},
      e('div',{style:{display:'flex',alignItems:'center',gap:10}},
        e('span',{style:{fontSize:18,fontWeight:800,color:N}},'TaxStat',e('span',{style:{color:B}},'360')),
        e('span',{style:{fontSize:11,background:'#EFF6FF',color:B,padding:'3px 10px',borderRadius:20,fontWeight:700}},'Meet Aria - Your AI Tax Advisor')
      ),
      e('div',{style:{display:'flex',gap:8}},
        e('button',{onClick:()=>nav('/tax-return'),style:{padding:'6px 14px',background:'none',border:'1px solid #E2E8F0',borderRadius:7,fontSize:13,color:SL,cursor:'pointer'}},'Back to 1040'),
        e('button',{onClick:()=>{localStorage.clear();nav('/')},style:{padding:'6px 14px',background:'none',border:'1px solid #E2E8F0',borderRadius:7,fontSize:13,color:SL,cursor:'pointer'}},'Sign Out')
      )
    ),
    e('div',{style:{maxWidth:900,width:'100%',margin:'0 auto',padding:'24px 20px',display:'flex',flexDirection:'column',flex:1}},
      // Context banner
      ctx.hasData&&e('div',{style:{background:'linear-gradient(135deg,#0D1B3E,#1e3a70)',borderRadius:12,padding:'12px 20px',marginBottom:20,display:'flex',alignItems:'center',justifyContent:'space-between',color:'#fff'}},
        e('div',{style:{display:'flex',gap:24}},
          e('div',null,
            e('div',{style:{fontSize:10,color:'rgba(255,255,255,0.5)',marginBottom:2}},'ENTITY'),
            e('div',{style:{fontSize:13,fontWeight:700}},{scorp:'S-Corp',mmllc:'Multi-Member LLC',partnership:'Partnership',soleprop:'Sole Proprietor',smllc:'Single-Member LLC'}[ctx.entity]||ctx.entity)
          ),
          ctx.k1>0&&e('div',null,
            e('div',{style:{fontSize:10,color:'rgba(255,255,255,0.5)',marginBottom:2}},'K-1 INCOME'),
            e('div',{style:{fontSize:13,fontWeight:700,color:'#4ADE80'}},'$'+Math.abs(ctx.k1).toLocaleString())
          ),
          ctx.tax>0&&e('div',null,
            e('div',{style:{fontSize:10,color:'rgba(255,255,255,0.5)',marginBottom:2}},'TAX LIABILITY'),
            e('div',{style:{fontSize:13,fontWeight:700,color:'#F87171'}},'$'+ctx.tax.toLocaleString())
          ),
          ctx.rate&&e('div',null,
            e('div',{style:{fontSize:10,color:'rgba(255,255,255,0.5)',marginBottom:2}},'EFFECTIVE RATE'),
            e('div',{style:{fontSize:13,fontWeight:700}},ctx.rate+'%')
          )
        ),
        e('div',{style:{fontSize:11,color:'rgba(255,255,255,0.4)'}},ctx.hasData?'Advice personalized to your return':'Complete your return for personalized advice')
      ),
      e('div',{style:{display:'flex',gap:4,marginBottom:20,background:'#fff',borderRadius:12,padding:4,border:'1px solid #E2E8F0'}},
        e('button',{onClick:()=>setActiveTab('aria'),style:{flex:1,padding:'10px',borderRadius:9,border:'none',fontSize:14,fontWeight:700,cursor:'pointer',fontFamily:'inherit',background:activeTab==='aria'?B:'transparent',color:activeTab==='aria'?'#fff':SL}},'Ask Aria'),
        e('button',{onClick:()=>setActiveTab('audit'),style:{flex:1,padding:'10px',borderRadius:9,border:'none',fontSize:14,fontWeight:700,cursor:'pointer',fontFamily:'inherit',background:activeTab==='audit'?'#DC2626':'transparent',color:activeTab==='audit'?'#fff':SL}},'Audit Risk Analyzer')
      ),
      activeTab==='aria'&&e('div',{style:{display:'flex',flexDirection:'column',flex:1}},
      // Chat messages
      e('div',{style:{flex:1,overflowY:'auto',marginBottom:16,display:'flex',flexDirection:'column',gap:12}},
        ...messages.map((msg,i)=>
          e('div',{key:i,style:{display:'flex',justifyContent:msg.role==='user'?'flex-end':'flex-start'}},
            msg.role==='assistant'&&e('div',{style:{width:32,height:32,borderRadius:'50%',background:'linear-gradient(135deg,#2563EB,#7C3AED)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:800,color:'#fff',flexShrink:0,alignSelf:'flex-end',marginBottom:2}},'A'),
            e('div',{style:{
              maxWidth:'80%',padding:'12px 16px',borderRadius:msg.role==='user'?'14px 14px 4px 14px':'14px 14px 14px 4px',
              background:msg.role==='user'?B:'#fff',
              color:msg.role==='user'?'#fff':N,
              fontSize:14,lineHeight:1.7,
              boxShadow:'0 1px 4px rgba(0,0,0,0.08)',
              border:msg.role==='assistant'?'1px solid #E2E8F0':'none'
            }},
            msg.role==='user'?msg.content:renderContent(msg.content))
          )
        ),
        loading&&e('div',{style:{display:'flex',justifyContent:'flex-start'}},
          e('div',{style:{padding:'12px 16px',borderRadius:'14px 14px 14px 4px',background:'#fff',border:'1px solid #E2E8F0',display:'flex',gap:4,alignItems:'center'}},
            ...[0,1,2].map(i=>e('div',{key:i,style:{width:8,height:8,borderRadius:'50%',background:B,opacity:0.4,animation:'pulse 1.2s ease-in-out '+(i*0.2)+'s infinite'}}))
          )
        ),
        e('div',{ref:endRef})
      ),
      // Suggested questions
      messages.length<=1&&e('div',{style:{marginBottom:16}},
        e('div',{style:{fontSize:12,fontWeight:700,color:SL,marginBottom:8}},'SUGGESTED QUESTIONS'),
        e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}},
          ...SUGGESTED.map((q,i)=>
            e('button',{key:i,onClick:()=>send(q),
              style:{padding:'8px 12px',background:'#fff',border:'1px solid #E2E8F0',borderRadius:8,fontSize:12,color:N,cursor:'pointer',textAlign:'left',fontFamily:'inherit',lineHeight:1.4}},
              q)
          )
        )
      ),
      // Input
      e('div',{style:{display:'flex',gap:8,background:'#fff',border:'1px solid #E2E8F0',borderRadius:12,padding:'8px 8px 8px 16px',boxShadow:'0 2px 8px rgba(0,0,0,0.06)'}},
        e('input',{
          value:input,
          onChange:x=>setInput(x.target.value),
          onKeyDown:x=>x.key==='Enter'&&!x.shiftKey&&send(),
          placeholder:'Ask Aria anything about your taxes...',
          style:{flex:1,border:'none',outline:'none',fontSize:14,fontFamily:'inherit',color:N,background:'transparent'}
        }),
        e('button',{onClick:()=>send(),disabled:loading||!input.trim(),
          style:{padding:'10px 20px',background:loading||!input.trim()?'#94A3B8':B,border:'none',borderRadius:9,fontSize:14,fontWeight:700,color:'#fff',cursor:loading||!input.trim()?'not-allowed':'pointer',fontFamily:'inherit',flexShrink:0}},
          loading?'..':'Ask')
      ),
      e('div',{style:{textAlign:'center',fontSize:11,color:'#94A3B8',marginTop:8}},'Aria provides educational tax information only. Consult a licensed CPA or tax attorney for implementation.')
      ),
      activeTab==='audit'&&e(AuditRiskAnalyzer,{ctx})
    ),
    e('style',null,`@keyframes pulse{0%,100%{opacity:0.4;transform:scale(1)}50%{opacity:1;transform:scale(1.2)}}`)
  )
}
