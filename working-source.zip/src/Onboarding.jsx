import React from 'react'
import{useNavigate}from 'react-router-dom'
const e=React.createElement
const N='#0D1B3E',B='#2563EB',SL='#475569'
const ADMIN_EMAIL='admin@taxstat360.com'
const ADMIN_PASS='TeddyBear2026!'
export default function Onboarding(){
  const nav=useNavigate()
  const[email,setEmail]=React.useState('')
  const[pass,setPass]=React.useState('')
  const[err,setErr]=React.useState('')
  const[loading,setLoading]=React.useState(false)
  function handleLogin(ev){
    ev.preventDefault()
    setErr('')
    setLoading(true)
    setTimeout(()=>{
      if(email.trim()===ADMIN_EMAIL && pass===ADMIN_PASS){
        localStorage.setItem('token','ts360-'+email.trim())
        nav('/calculate-tax')
      } else {
        setErr('Invalid email or password')
        setLoading(false)
      }
    },600)
  }
  return e('div',{style:{minHeight:'100vh',background:'#F8FAFC',fontFamily:'system-ui,sans-serif',display:'flex',alignItems:'center',justifyContent:'center'}},
    e('div',{style:{background:'#fff',borderRadius:16,padding:40,width:380,boxShadow:'0 4px 24px rgba(0,0,0,0.08)',border:'1px solid #E2E8F0'}},
      e('div',{style:{textAlign:'center',marginBottom:28}},
        e('div',{style:{fontSize:26,fontWeight:800,color:N,marginBottom:4}},'TaxStat',e('span',{style:{color:B}},'360')),
        e('div',{style:{fontSize:14,color:SL}})
      ),
      e('form',{onSubmit:handleLogin},
        e('div',{style:{marginBottom:16}},
          e('label',{style:{fontSize:12,fontWeight:700,color:SL,display:'block',marginBottom:6}},'Email Address'),
          e('input',{type:'email',value:email,onChange:v=>setEmail(v.target.value),placeholder:'admin@taxstat360.com',required:true,
            style:{width:'100%',padding:'11px 14px',border:'1px solid #E2E8F0',borderRadius:8,fontSize:15,boxSizing:'border-box',fontFamily:'inherit',outline:'none'}})
        ),
        e('div',{style:{marginBottom:20}},
          e('label',{style:{fontSize:12,fontWeight:700,color:SL,display:'block',marginBottom:6}},'Password'),
          e('input',{type:'password',value:pass,onChange:v=>setPass(v.target.value),placeholder:'Enter password',required:true,
            style:{width:'100%',padding:'11px 14px',border:'1px solid #E2E8F0',borderRadius:8,fontSize:15,boxSizing:'border-box',fontFamily:'inherit',outline:'none'}})
        ),
        err&&e('div',{style:{background:'#FEF2F2',border:'1px solid #FECACA',borderRadius:8,padding:'10px 14px',fontSize:13,color:'#dc2626',marginBottom:16}},err),
        e('button',{type:'submit',disabled:loading,style:{width:'100%',padding:'13px',background:B,border:'none',borderRadius:9,fontSize:15,fontWeight:700,color:'#fff',cursor:loading?'not-allowed':'pointer',fontFamily:'inherit',opacity:loading?0.7:1}},
          loading?'Signing in...':'Sign In'
        )
      )
    )
  )
}
