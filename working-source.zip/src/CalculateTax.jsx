import React from 'react'
import{useNavigate}from 'react-router-dom'
const e=React.createElement
const N='#0D1B3E',B='#2563EB',SL='#475569',G='#16a34a',R='#dc2626'
const API='https://05madmjrqd.execute-api.us-east-1.amazonaws.com/prod'
const INTS=[{id:'quickbooks',name:'QuickBooks',color:'#2CA01C',abbr:'QB'},{id:'xero',name:'Xero',color:'#13B5EA',abbr:'XE'},{id:'wave',name:'Wave',color:'#2C6ECB',abbr:'WV'},{id:'freshbooks',name:'FreshBooks',color:'#1a9c3e',abbr:'FB'}]
const fmt=n=>'$'+Math.abs(Math.round(n)||0).toLocaleString('en-US')
const nv=v=>parseFloat((v||'').toString().replace(/[^0-9.-]/g,''))||0
const OWN=[['100','100% (sole owner)'],['75','75%'],['67','67%'],['60','60%'],['50','50% (equal partners)'],['40','40%'],['33','33%'],['25','25%'],['20','20%'],['10','10%']]
export default function CalculateTax(){
  const nav=useNavigate()
  const[conn,setConn]=React.useState({})
  const[syn,setSyn]=React.useState(null)
  const[pnl,setPnl]=React.useState(null)
  const[manual,setManual]=React.useState(false)
  const[manRev,setManRev]=React.useState('')
  const[manExp,setManExp]=React.useState('')
  const[own,setOwn]=React.useState('100')
  const cId=Object.keys(conn).find(k=>conn[k])
  React.useEffect(()=>{
    const c={};for(const i of INTS){if(localStorage.getItem('ts360_'+i.id+'_connected')==='true')c[i.id]=true}
    setConn(c)
    const p=new URLSearchParams(window.location.search)
    const mp={qb_token:'quickbooks',xero_token:'xero',wave_token:'wave',fb_token:'freshbooks'}
    for(const[k,pid]of Object.entries(mp)){const tok=p.get(k);if(tok){localStorage.setItem('ts360_'+pid+'_connected','true');localStorage.setItem('ts360_'+pid+'_token',tok);const ex={quickbooks:p.get('realm'),xero:p.get('tenant'),freshbooks:p.get('account')};if(ex[pid])localStorage.setItem('ts360_'+pid+'_extra',ex[pid]);setConn(prev=>({...prev,[pid]:true}));fetchPnL(pid,tok,ex[pid]);window.history.replaceState({},'','/calculate-tax')}}
  },[])
  async function fetchPnL(pid,tok,extra){setSyn(pid);try{let url=API+'/auth/'+pid+'/data?token='+encodeURIComponent(tok);if(pid==='quickbooks'&&extra)url+='&realm='+extra;if(pid==='xero'&&extra)url+='&tenant='+extra;if(pid==='freshbooks'&&extra)url+='&account='+extra;const d=await(await fetch(url)).json();if(d&&!d.error){setPnl(d);setManual(false)}}catch(ex){console.error(ex)}setSyn(null)}
  function refresh(id){const t=localStorage.getItem('ts360_'+id+'_token'),x=localStorage.getItem('ts360_'+id+'_extra');if(t)fetchPnL(id,t,x)}
  function disc(id){localStorage.removeItem('ts360_'+id+'_connected');localStorage.removeItem('ts360_'+id+'_token');localStorage.removeItem('ts360_'+id+'_extra');setConn(p=>{const c={...p};delete c[id];return c});setPnl(null)}
  function applyManual(){const r=nv(manRev),ex=nv(manExp);if(r>0||ex>0)setPnl({grossRevenue:r,totalExpenses:ex,netProfit:r-ex,categories:{}})}
  function proceed(){
    const k1=pnl?Math.round(pnl.netProfit*(parseInt(own)/100)):0
    sessionStorage.setItem('ts360_k1',k1)
    sessionStorage.setItem('ts360_own',own)
    nav('/tax-return')
  }
  const net=pnl?.netProfit||0
  const k1=Math.round(net*(parseInt(own)/100))
  return e('div',{style:{minHeight:'100vh',background:'#F8FAFC',fontFamily:'system-ui,sans-serif',color:N}},
    e('nav',{style:{background:'#fff',borderBottom:'1px solid #E2E8F0',padding:'0 40px',height:60,display:'flex',alignItems:'center',justifyContent:'space-between',position:'sticky',top:0,zIndex:100}},
      e('div',{style:{display:'flex',alignItems:'center',gap:12}},
        e('span',{style:{fontSize:19,fontWeight:800,color:N}},'TaxStat',e('span',{style:{color:B}},'360')),
        e('span',{style:{fontSize:12,background:'#EFF6FF',color:B,padding:'3px 10px',borderRadius:20,fontWeight:600}},'Step 1 of 2 \u2014 Business')
      ),
      e('div',{style:{display:'flex',gap:8}},
        e('button',{onClick:()=>nav('/ai-analysis'),style:{padding:'7px 14px',background:'none',border:'1px solid #E2E8F0',borderRadius:7,fontSize:13,color:SL,cursor:'pointer'}},'AI Analysis'),
        e('button',{onClick:()=>{localStorage.clear();nav('/')},style:{padding:'7px 14px',background:'none',border:'1px solid #E2E8F0',borderRadius:7,fontSize:13,color:SL,cursor:'pointer'}},'Sign Out')
      )
    ),
    e('div',{style:{maxWidth:1100,margin:'0 auto',padding:'32px 20px'}},
      e('h1',{style:{fontSize:26,fontWeight:800,color:N,textAlign:'center',marginBottom:4}},'Business Income & K-1 Calculator'),
      e('p',{style:{textAlign:'center',color:SL,fontSize:14,marginBottom:28}},'Connect your accounting software to import your Profit & Loss, then calculate your K-1 distributive share'),
      e('div',{style:{background:'#fff',borderRadius:14,padding:24,border:'1px solid #E2E8F0',marginBottom:20}},
        e('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:18}},
          e('div',{style:{fontSize:11,fontWeight:700,letterSpacing:'1px',color:SL}},'CONNECT YOUR ACCOUNTING SOFTWARE'),
          e('button',{onClick:()=>{setManual(!manual);if(manual)setPnl(null)},style:{padding:'5px 14px',background:'none',border:'1px solid '+B,borderRadius:6,fontSize:12,fontWeight:600,color:B,cursor:'pointer'}},manual?'\u2190 Use Software':'\u270f\ufe0f Enter Manually')
        ),
        !manual&&e('div',{style:{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12}},
          ...INTS.map(i=>{const isC=!!conn[i.id],isS=syn===i.id;return e('div',{key:i.id,style:{border:'2px solid '+(isC?i.color:'#E2E8F0'),borderRadius:12,padding:16,textAlign:'center',background:isC?i.color+'0D':'#fff'}},e('div',{style:{width:38,height:38,borderRadius:9,background:i.color,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 8px',fontSize:12,fontWeight:700,color:'#fff'}},i.abbr),e('div',{style:{fontSize:13,fontWeight:700,color:N,marginBottom:8}},i.name),isC?e('div',null,e('div',{style:{fontSize:12,color:G,fontWeight:700,marginBottom:8}},isS?'\u27f3 Syncing...':'\u2713 Connected'),e('div',{style:{display:'flex',gap:6,justifyContent:'center'}},e('button',{onClick:()=>refresh(i.id),style:{padding:'4px 10px',background:'#EFF6FF',border:'1px solid #BFDBFE',borderRadius:5,fontSize:11,fontWeight:600,color:B,cursor:'pointer'}},'\u27f3 Refresh'),e('button',{onClick:()=>disc(i.id),style:{padding:'4px 10px',background:'#FEF2F2',border:'1px solid #FECACA',borderRadius:5,fontSize:11,fontWeight:600,color:R,cursor:'pointer'}},'Disconnect'))):e('button',{onClick:()=>{window.location.href=API+'/auth/'+i.id+'/connect'},style:{width:'100%',padding:'8px',background:B,border:'none',borderRadius:7,fontSize:12,fontWeight:600,color:'#fff',cursor:'pointer'}},isS?'Connecting...':'Connect'))})
        ),
        manual&&e('div',{style:{background:'#F8FAFC',borderRadius:10,padding:20,border:'1px solid #E2E8F0'}},
          e('div',{style:{fontSize:13,fontWeight:700,color:N,marginBottom:14}},'\u270f\ufe0f Manual P&L Entry \u2014 '+new Date().getFullYear()+' Year-to-Date'),
          e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16,marginBottom:14}},
            e('div',null,e('label',{style:{fontSize:11,fontWeight:700,color:SL,display:'block',marginBottom:4}},'Total Revenue / Gross Income'),e('input',{value:manRev,onChange:v=>setManRev(v.target.value),placeholder:'0',type:'number',style:{width:'100%',padding:'10px 14px',border:'2px solid #E2E8F0',borderRadius:8,fontSize:15,boxSizing:'border-box',fontFamily:'inherit'}})),
            e('div',null,e('label',{style:{fontSize:11,fontWeight:700,color:SL,display:'block',marginBottom:4}},'Total Business Expenses'),e('input',{value:manExp,onChange:v=>setManExp(v.target.value),placeholder:'0',type:'number',style:{width:'100%',padding:'10px 14px',border:'2px solid #E2E8F0',borderRadius:8,fontSize:15,boxSizing:'border-box',fontFamily:'inherit'}}))
          ),
          e('div',{style:{display:'flex',alignItems:'center',justifyContent:'space-between'}},
            e('div',{style:{fontSize:14,color:SL}},manRev||manExp?e('span',null,'Net: ',e('strong',{style:{color:nv(manRev)-nv(manExp)>=0?G:R}},fmt(nv(manRev)-nv(manExp)))):'Enter your figures above'),
            e('button',{onClick:applyManual,style:{padding:'9px 20px',background:G,border:'none',borderRadius:7,fontSize:13,fontWeight:700,color:'#fff',cursor:'pointer'}},'Apply \u2192')
          )
        )
      ),
      pnl&&e('div',null,
        e('div',{style:{background:'#fff',borderRadius:14,padding:24,border:'1px solid #E2E8F0',marginBottom:20}},
          e('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}},
            e('div',{style:{fontSize:11,fontWeight:700,letterSpacing:'1px',color:SL}},manual?'MANUAL P&L ENTRY':'P&L FROM '+(cId||'').toUpperCase()+' \u2014 '+new Date().getFullYear()+' YTD'),
            e('div',{style:{display:'flex',gap:8}},
              !manual&&cId&&e('button',{onClick:()=>refresh(cId),style:{padding:'4px 10px',background:'#EFF6FF',border:'1px solid #BFDBFE',borderRadius:5,fontSize:11,fontWeight:600,color:B,cursor:'pointer'}},'\u27f3 Refresh'),
              e('button',{onClick:()=>setPnl(null),style:{padding:'4px 10px',background:'#FEF2F2',border:'1px solid #FECACA',borderRadius:5,fontSize:11,fontWeight:600,color:R,cursor:'pointer'}},'\u2715 Clear')
            )
          ),
          e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12,marginBottom:pnl.categories&&Object.keys(pnl.categories).length>0?20:0}},
            ...[['Total Revenue',fmt(pnl.grossRevenue),G,'\ud83d\udcc8'],['Total Expenses',fmt(pnl.totalExpenses),R,'\ud83d\udcc9'],['Net Profit / Loss',fmt(pnl.netProfit),pnl.netProfit>=0?G:R,'\ud83d\udcb0']].map(([l,v,c,ic])=>
              e('div',{key:l,style:{background:'#F8FAFC',borderRadius:10,padding:16,textAlign:'center',border:'1px solid #F1F5F9'}},
                e('div',{style:{fontSize:18,marginBottom:4}},ic),
                e('div',{style:{fontSize:11,color:SL,marginBottom:3}},l),
                e('div',{style:{fontSize:22,fontWeight:800,color:c}},v)
              )
            )
          ),
          pnl.categories&&Object.keys(pnl.categories).length>0&&e('div',null,
            e('div',{style:{fontSize:11,fontWeight:700,color:SL,marginBottom:10}},'EXPENSE BREAKDOWN'),
            e('div',{style:{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}},
              ...Object.entries(pnl.categories).sort((a,b)=>b[1]-a[1]).map(([cat,amt])=>e('div',{key:cat,style:{background:'#F8FAFC',borderRadius:8,padding:'9px 12px',display:'flex',justifyContent:'space-between',alignItems:'center',border:'1px solid #F1F5F9'}},e('div',null,e('div',{style:{fontSize:12,fontWeight:600,color:N}},cat),e('div',{style:{fontSize:10,color:SL}},pnl.totalExpenses>0?Math.round((amt/pnl.totalExpenses)*100)+'% of expenses':'')),e('div',{style:{fontSize:12,fontWeight:700,color:R}},fmt(amt))))
            )
          )
        ),
        e('div',{style:{background:'#fff',borderRadius:14,padding:24,border:'1px solid #E2E8F0',marginBottom:20}},
          e('div',{style:{fontSize:11,fontWeight:700,letterSpacing:'1px',color:SL,marginBottom:18}},'OWNERSHIP PERCENTAGE & K-1 SHARE'),
          e('div',{style:{display:'grid',gridTemplateColumns:'280px 1fr',gap:24,alignItems:'center'}},
            e('div',null,
              e('label',{style:{fontSize:13,fontWeight:700,color:N,display:'block',marginBottom:10}},'Your Ownership %'),
              e('select',{value:own,onChange:v=>setOwn(v.target.value),style:{width:'100%',padding:'12px 16px',border:'2px solid '+B,borderRadius:10,fontSize:16,fontWeight:700,color:N,background:'#fff',fontFamily:'inherit',cursor:'pointer'}},
                ...OWN.map(([v,l])=>e('option',{key:v,value:v},l))
              ),
              e('div',{style:{fontSize:11,color:SL,marginTop:8,lineHeight:1.5}},'For S-Corps, LLCs, and partnerships with multiple owners. Single-owner businesses are always 100%.')
            ),
            e('div',{style:{background:'linear-gradient(135deg,#0D1B3E 0%,#1e3a70 100%)',borderRadius:12,padding:24,color:'#fff',textAlign:'center'}},
              e('div',{style:{fontSize:12,color:'rgba(255,255,255,0.5)',marginBottom:6,letterSpacing:'0.5px'}},'YOUR K-1 DISTRIBUTIVE SHARE'),
              e('div',{style:{fontSize:46,fontWeight:800,color:k1>=0?'#4ADE80':'#F87171',lineHeight:1}},fmt(k1)),
              e('div',{style:{fontSize:12,color:'rgba(255,255,255,0.45)',marginTop:8}},fmt(pnl.netProfit)+' net profit \u00d7 '+own+'% ownership'),
              e('div',{style:{fontSize:12,color:'rgba(255,255,255,0.45)',marginTop:12,padding:'8px 0',borderTop:'1px solid rgba(255,255,255,0.1)'}},k1>=0?'Flows to your personal Schedule E on Form 1040':'Loss may offset other income on your personal return')
            )
          )
        ),
        e('div',{style:{textAlign:'center',paddingBottom:40}},
          e('button',{onClick:proceed,style:{padding:'16px 52px',background:B,border:'none',borderRadius:12,fontSize:17,fontWeight:800,color:'#fff',cursor:'pointer',boxShadow:'0 4px 24px rgba(37,99,235,0.35)'}},
            'Continue to Personal Tax Return (Form 1040) \u2192'
          ),
          e('div',{style:{fontSize:12,color:SL,marginTop:10}},'Your K-1 of '+fmt(k1)+' will be pre-filled on the next page')
        )
      ),
      !pnl&&e('div',{style:{textAlign:'center',padding:'48px 20px',color:SL}},
        e('div',{style:{fontSize:52,marginBottom:12}},'\ud83d\udcca'),
        e('div',{style:{fontSize:17,fontWeight:700,color:N,marginBottom:8}},'Connect your accounting software above'),
        e('div',{style:{fontSize:14}},'Or click "Enter Manually" to type in your revenue and expenses')
      )
    )
  )
}