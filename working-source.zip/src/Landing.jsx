
import React from 'react'
import{useNavigate}from 'react-router-dom'
const e=React.createElement
const N='#0D1B3E',B='#2563EB',SL='#475569'
const TIERS=[
  {name:'Starter',price:'$79',badge:'Get Started',popular:false,accent:'#3B82F6',desc:'Everything you need to know what you owe right now.',features:['Real-time tax liability calculator','K-1 generation (S-Corps, partnerships, LLCs)','Schedule C (sole props and SMLLCs)','C-Corp entity-level tax calculation','Quarterly estimated payment planner','IRS deadline and penalty awareness','Plain English language mode','Connect 1 accounting software','Manual data entry option']},
  {name:'Professional',price:'$149',badge:'Most Popular',popular:true,accent:'#60A5FA',desc:'AI that watches your numbers and flags problems before they cost you.',features:['Everything in Starter plus:','Real-Time Risk Alert Engine','Explainable AI: Why This Number?','AI Assumption Transparency Panel','Financial Data Anomaly Detection','Data Confidence Score','Tax-Saving Opportunity Discovery','AI-Generated Financial Action Plan','Mid-Year Tax and Risk Pulse','Safe Harbor Rule Detection','IRS Schedule Mapping C E K-1','Depreciation Compliance Engine','Compliance Confidence Indicator','Connect up to 2 accounting software accounts']},
  {name:'Advanced',price:'$299',badge:'Full IRS Armor',popular:false,accent:'#34D399',desc:'Multi-entity management, CPA collaboration, and full audit defense.',features:['Everything in Professional plus:','What-If Scenario Simulator','Risk Tolerance Profiling','Industry Benchmark Intelligence','AI Recommendation Change Tracking','Year-Over-Year Intelligence','Event-Triggered AI Re-Analysis','Multi-Entity / Multi-Business View','Advisor and Accountant Collaboration','IRS Audit Readiness Mode','AI-Generated Audit Defense Narrative','State-Level Tax Awareness','IRS Rule Change Monitoring','Compliance-Grade AI Guardrails','IRS-Aligned Data Retention and Audit Trail','Support Replay and Audit Mode']}
]
const WHO=[
  {icon:'🏢',title:'S-Corporations',desc:'Officer W-2 salary, K-1 generation, and distributions all flow correctly to your personal 1040.',tag:'K-1'},
  {icon:'🤝',title:'Partnerships and Multi-Member LLCs',desc:'Each partners distributive share calculated separately. K-1 flows directly into your personal tax return.',tag:'K-1'},
  {icon:'📝',title:'Sole Proprietors and Freelancers',desc:'Net profit hits Schedule C. SE tax, QBI deduction, and your real bottom line calculated instantly.',tag:'Sch C'},
  {icon:'🏗️',title:'C-Corporations',desc:'21% flat rate entity-level calculation. Understand after-tax profit and quarterly payment schedule.',tag:'Corp'},
  {icon:'💼',title:'W-2 Plus Business Owner',desc:'Have a day job and a business? We combine all income sources for your complete tax picture.',tag:'Combined'},
  {icon:'📊',title:'Multiple Entities',desc:'Run multiple businesses? Connect each accounting system and see your consolidated tax exposure.',tag:'Multi'}
]
const AI=[
  {icon:'🚨',label:'Real-Time Risk Alerts'},{icon:'🎯',label:'What-If Simulator'},
  {icon:'💡',label:'Tax-Saving Discovery'},{icon:'📋',label:'K-1 Auto-Generation'},
  {icon:'🛡️',label:'Audit Defense AI'},{icon:'📊',label:'Compliance Score'},
  {icon:'🔄',label:'Year-Over-Year Intel'},{icon:'🏢',label:'Multi-Entity View'}
]
const INTS=[{abbr:'QB',name:'QuickBooks',color:'#2CA01C'},{abbr:'XE',name:'Xero',color:'#13B5EA'},{abbr:'WV',name:'Wave',color:'#2C6ECB'},{abbr:'FB',name:'FreshBooks',color:'#1a9c3e'}]

export default function Landing(){
  const nav=useNavigate()
  const btn=(txt,fn,bg,col,border)=>e('button',{onClick:fn,style:{padding:'10px 24px',background:bg||B,border:border||'none',borderRadius:8,fontSize:14,fontWeight:600,color:col||'#fff',cursor:'pointer'}},txt)
  
  return e('div',{style:{fontFamily:'system-ui,sans-serif',background:'#fff',color:N,margin:0}},
    // NAV
    e('nav',{style:{position:'fixed',top:0,left:0,right:0,zIndex:100,background:'rgba(255,255,255,0.96)',borderBottom:'1px solid #E2E8F0',padding:'0 40px',height:64,display:'flex',alignItems:'center',justifyContent:'space-between'}},
      e('div',{style:{display:'flex',alignItems:'center',gap:10}},
        e('div',{style:{width:36,height:36,background:N,borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center'}},
          e('svg',{width:20,height:20,viewBox:'0 0 20 20',fill:'none'},
            e('rect',{x:2,y:10,width:3,height:8,rx:1,fill:'#fff'}),
            e('rect',{x:8,y:6,width:3,height:12,rx:1,fill:'#fff'}),
            e('rect',{x:14,y:2,width:3,height:16,rx:1,fill:'#fff'})
          )
        ),
        e('span',{style:{fontSize:20,fontWeight:700,color:N,borderBottom:'2px solid '+N,paddingBottom:'1px',display:'inline-block'}},'TaxStat',e('span',{style:{color:B}},'360')),
        e('div',{style:{fontSize:9,fontWeight:700,letterSpacing:'2px',color:'#94A3B8',marginTop:-4,paddingLeft:1}},'ACCURATE · AUDIT PROOF · ASSET BUILDING')
      ),
      e('div',{style:{display:'flex',gap:8}},
        btn('Sign In',()=>nav('/login'),'none',SL,'1px solid #E2E8F0'),
        btn('Start Free Trial',()=>nav('/signup'))
      )
    ),
    // HERO
    e('div',{style:{paddingTop:130,paddingBottom:80,background:'linear-gradient(160deg,#EFF6FF 0%,#fff 60%)',textAlign:'center',padding:'130px 40px 80px'}},
      e('div',{style:{display:'inline-block',background:'#EFF6FF',border:'1px solid #BFDBFE',borderRadius:20,padding:'5px 16px',fontSize:12,fontWeight:700,color:B,marginBottom:24,letterSpacing:'0.8px'}},'✦ GET IN FRONT OF YOUR LARGEST EXPENSE'),
      e('h1',{style:{fontSize:52,fontWeight:800,lineHeight:1.1,color:N,marginBottom:24,maxWidth:800,margin:'0 auto 24px'}},'Building Wealth Starts With Eliminating Your Tax Liability.'),
      e('p',{style:{fontSize:18,color:SL,lineHeight:1.7,marginBottom:40,maxWidth:580,margin:'0 auto 40px'}},'Your tax bill is your single largest wealth-destroying expense. TaxStat360 shows you exactly what you owe — and more importantly, what you can legally eliminate. Real numbers. Real strategies. Right now.'),
      e('div',{style:{display:'flex',gap:12,justifyContent:'center',flexWrap:'wrap',marginBottom:16}},
        e('button',{onClick:()=>nav('/signup'),style:{padding:'15px 36px',background:B,border:'none',borderRadius:10,fontSize:16,fontWeight:700,color:'#fff',cursor:'pointer',boxShadow:'0 6px 24px rgba(37,99,235,0.35)'}},'Start Free 7-Day Trial'),
        e('button',{onClick:()=>nav('/login'),style:{padding:'15px 24px',background:'#fff',border:'1px solid #E2E8F0',borderRadius:10,fontSize:15,color:SL,cursor:'pointer'}},'Already have an account')
      ),
      e('p',{style:{fontSize:13,color:'#94A3B8',marginBottom:32}},'No charge until after 7-day trial · Cancel anytime · No CPA required'),
      e('div',{style:{display:'flex',gap:10,justifyContent:'center',flexWrap:'wrap',alignItems:'center'}},
        e('span',{style:{fontSize:13,color:'#94A3B8'}},'Connects with'),
        ...INTS.map(i=>e('div',{key:i.abbr,style:{display:'flex',alignItems:'center',gap:7,background:'#F8FAFC',border:'1px solid #E2E8F0',borderRadius:20,padding:'5px 12px'}},
          e('div',{style:{width:22,height:22,borderRadius:5,background:i.color,display:'flex',alignItems:'center',justifyContent:'center',fontSize:9,fontWeight:700,color:'#fff'}},i.abbr),
          e('span',{style:{fontSize:13,fontWeight:500,color:N}},i.name)
        ))
      )
    ),
    // VIDEO
    e('div',{style:{background:N,padding:'80px 40px'}},
      e('div',{style:{maxWidth:900,margin:'0 auto'}},
        e('h2',{style:{fontFamily:'serif',fontSize:36,color:'#fff',textAlign:'center',marginBottom:12}},'Watch the Demo Below'),
        e('p',{style:{color:'rgba(255,255,255,0.6)',textAlign:'center',marginBottom:40,fontSize:16}},'See how business owners legally eliminate their tax liability and keep more of what they earn'),
        e('div',{style:{position:'relative',paddingBottom:'56.25%',height:0,borderRadius:16,overflow:'hidden',boxShadow:'0 32px 80px rgba(0,0,0,0.4)'}},
          e('iframe',{src:'https://player.vimeo.com/video/1180620888?autoplay=0&title=0&byline=0&portrait=0',style:{position:'absolute',top:0,left:0,width:'100%',height:'100%',border:'none'},allow:'autoplay; fullscreen; picture-in-picture',allowFullScreen:true,title:'TaxStat360 Demo'})
        )
      )
    ),
    // WHO
    e('div',{style:{padding:'80px 40px',background:'#F8FAFC'}},
      e('div',{style:{maxWidth:1100,margin:'0 auto'}},
        e('h2',{style:{fontFamily:'serif',fontSize:38,color:N,textAlign:'center',marginBottom:12}},'Built to Build Wealth — No Matter Your Entity Structure'),
        e('p',{style:{color:SL,textAlign:'center',fontSize:16,marginBottom:48}},'S-Corp, LLC, Partnership, Sole Prop — every structure has legal strategies to reduce what you owe. TaxStat360 knows them all.'),
        e('div',{style:{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:18}},
          ...WHO.map(w=>e('div',{key:w.title,style:{background:'#fff',borderRadius:14,padding:26,border:'1px solid #E2E8F0'}},
            e('div',{style:{fontSize:34,marginBottom:14}},w.icon),
            e('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:10}},
              e('div',{style:{fontSize:15,fontWeight:700,color:N}},w.title),
              e('span',{style:{fontSize:10,fontWeight:700,background:'#EFF6FF',color:B,border:'1px solid #BFDBFE',borderRadius:20,padding:'3px 8px',whiteSpace:'nowrap'}},w.tag)
            ),
            e('p',{style:{fontSize:14,color:SL,lineHeight:1.6,margin:0}},w.desc)
          ))
        )
      )
    ),
    // HOW IT WORKS
    e('div',{style:{padding:'80px 40px',background:'#fff'}},
      e('div',{style:{maxWidth:900,margin:'0 auto',textAlign:'center'}},
        e('h2',{style:{fontFamily:'serif',fontSize:38,color:N,marginBottom:12}},'Your tax bill in 3 steps'),
        e('p',{style:{color:SL,fontSize:16,marginBottom:48}},'From connected to calculated in under 5 minutes'),
        e('div',{style:{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:24}},
          ...['Connect your software|Link QuickBooks, Xero, Wave, or FreshBooks. We pull your income and expense totals — no sub-accounts, just the numbers that matter.','Enter your personal info|Filing status, any W-2 income, dependents. For K-1 entities we auto-apply your ownership percentage and flow income to your 1040.','See your real tax bill|Complete tax liability, quarterly payments, QBI deduction savings, and K-1 breakdown — updated in real time as you adjust numbers.'].map((s,i)=>{
            const[title,desc]=s.split('|')
            return e('div',{key:i,style:{padding:'0 8px'}},
              e('div',{style:{width:56,height:56,borderRadius:'50%',background:'#EFF6FF',border:'2px solid #BFDBFE',display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 20px',fontSize:20,fontWeight:700,color:B}},`0${i+1}`),
              e('div',{style:{fontSize:16,fontWeight:700,color:N,marginBottom:10}},title),
              e('p',{style:{fontSize:14,color:SL,lineHeight:1.7,margin:0}},desc)
            )
          })
        )
      )
    ),
    // PRICING
    e('div',{style:{padding:'80px 40px',background:'#F8FAFC'}},
      e('div',{style:{maxWidth:1100,margin:'0 auto'}},
        e('h2',{style:{fontFamily:'serif',fontSize:38,color:N,textAlign:'center',marginBottom:12}},'Simple, transparent pricing'),
        e('p',{style:{color:SL,textAlign:'center',fontSize:16,marginBottom:48}},'7-day free trial on all plans · No charge until trial ends · Cancel anytime'),
        e('div',{style:{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:20,alignItems:'start'}},
          ...TIERS.map(tier=>e('div',{key:tier.name,style:{background:tier.popular?N:'#fff',borderRadius:16,padding:'32px 28px',border:tier.popular?'none':'1px solid #E2E8F0',boxShadow:tier.popular?'0 24px 60px rgba(13,27,62,0.25)':'none',position:'relative',transform:tier.popular?'scale(1.03)':'none'}},
            tier.popular&&e('div',{style:{position:'absolute',top:-14,left:'50%',transform:'translateX(-50%)',background:B,color:'#fff',fontSize:11,fontWeight:700,padding:'5px 16px',borderRadius:20,whiteSpace:'nowrap'}},'✦ MOST POPULAR'),
            e('div',{style:{fontSize:11,fontWeight:700,color:tier.popular?'rgba(255,255,255,0.5)':SL,letterSpacing:'1px',marginBottom:8}},tier.badge.toUpperCase()),
            e('div',{style:{fontSize:24,fontWeight:800,color:tier.popular?'#fff':N,marginBottom:4}},tier.name),
            e('div',{style:{display:'flex',alignItems:'baseline',gap:4,marginBottom:12}},
              e('span',{style:{fontSize:46,fontWeight:800,color:tier.popular?'#fff':N}},tier.price),
              e('span',{style:{fontSize:14,color:tier.popular?'rgba(255,255,255,0.5)':SL}},'/mo')
            ),
            e('p',{style:{fontSize:13,color:tier.popular?'rgba(255,255,255,0.65)':SL,marginBottom:24,lineHeight:1.6}},tier.desc),
            e('button',{onClick:()=>nav('/signup?plan='+tier.name.toLowerCase()),style:{width:'100%',padding:'12px',background:tier.popular?B:'#fff',border:tier.popular?'none':'2px solid '+N,borderRadius:9,fontSize:14,fontWeight:700,color:tier.popular?'#fff':N,cursor:'pointer',marginBottom:24}},'Start Free Trial'),
            e('div',{style:{borderTop:'1px solid '+(tier.popular?'rgba(255,255,255,0.12)':'#E2E8F0'),paddingTop:20}},
              ...tier.features.map((f,i)=>e('div',{key:i,style:{display:'flex',gap:10,alignItems:'flex-start',marginBottom:10}},
                e('span',{style:{color:f.includes('plus')||(f.includes('Everything'))?(tier.popular?'rgba(255,255,255,0.4)':'#94A3B8'):tier.accent,fontSize:14,flexShrink:0}},f.includes('plus')||f.includes('Everything')?'↑':'✓'),
                e('span',{style:{fontSize:13,color:tier.popular?'rgba(255,255,255,0.85)':SL,lineHeight:1.5}},f)
              ))
            )
          ))
        )
      )
    ),
    // AI FEATURES
    e('div',{style:{padding:'80px 40px',background:N}},
      e('div',{style:{maxWidth:1100,margin:'0 auto',display:'grid',gridTemplateColumns:'1fr 1fr',gap:80,alignItems:'center'}},
        e('div',null,
          e('div',{style:{fontSize:11,fontWeight:700,color:'rgba(255,255,255,0.4)',letterSpacing:'1.5px',marginBottom:16}},'32 AI-POWERED FEATURES'),
          e('h2',{style:{fontFamily:'serif',fontSize:36,color:'#fff',marginBottom:20,lineHeight:1.2}},'More than a calculator. A proactive tax intelligence engine.'),
          e('p',{style:{fontSize:16,color:'rgba(255,255,255,0.65)',lineHeight:1.7,marginBottom:32}},'TaxStat360 watches your financials year-round — flagging audit risks, finding deductions you are missing, and keeping you ahead of IRS deadlines. Built for US-specific IRS, state, and federal requirements.'),
          e('button',{onClick:()=>nav('/signup'),style:{padding:'14px 32px',background:B,border:'none',borderRadius:10,fontSize:15,fontWeight:700,color:'#fff',cursor:'pointer'}},'Explore All Features')
        ),
        e('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
          ...AI.map(f=>e('div',{key:f.label,style:{background:'rgba(255,255,255,0.06)',border:'1px solid rgba(255,255,255,0.1)',borderRadius:12,padding:16,display:'flex',alignItems:'center',gap:10}},
            e('span',{style:{fontSize:22}},f.icon),
            e('span',{style:{fontSize:13,fontWeight:500,color:'rgba(255,255,255,0.8)'}},f.label)
          ))
        )
      )
    ),
    // CTA
    e('div',{style:{padding:'80px 40px',background:'#fff',textAlign:'center'}},
      e('div',{style:{maxWidth:600,margin:'0 auto'}},
        e('h2',{style:{fontFamily:'serif',fontSize:40,color:N,marginBottom:16,lineHeight:1.15}},'Stop guessing what you owe.'),
        e('p',{style:{fontSize:17,color:SL,marginBottom:36,lineHeight:1.7}},'Join thousands of small business owners who use TaxStat360 to see their real tax liability every month, in real time.'),
        e('button',{onClick:()=>nav('/signup'),style:{padding:'16px 40px',background:B,border:'none',borderRadius:10,fontSize:17,fontWeight:700,color:'#fff',cursor:'pointer',boxShadow:'0 8px 28px rgba(37,99,235,0.35)',display:'block',margin:'0 auto 16px'}},'Start Your Free 7-Day Trial'),
        e('p',{style:{fontSize:13,color:'#94A3B8'}},'No credit card charged until trial ends · Cancel anytime')
      )
    ),
    // FOOTER
    e('footer',{style:{background:N,padding:'40px',display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:16}},
      e('span',{style:{fontSize:16,fontWeight:700,color:'#fff'}},'TaxStat',e('span',{style:{color:'#60A5FA'}},'360')),
      e('div',{style:{display:'flex',gap:24}},
        ...['Privacy Policy','Terms of Service','Contact'].map(l=>e('span',{key:l,style:{fontSize:13,color:'rgba(255,255,255,0.4)',cursor:'pointer'}},l))
      ),
      e('p',{style:{fontSize:12,color:'rgba(255,255,255,0.3)',margin:0}},'2024 TaxStat360 · support@themoneynista.com')
    )
  )
}
